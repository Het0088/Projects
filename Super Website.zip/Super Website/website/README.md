# Basketball Central Website

A modern, interactive basketball information website with live scores, team information, and player stats.

## Features

- Interactive team and player information
- User authentication system
- Live scores and updates
- Responsive design for all devices

## Installation

1. Clone this repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file with your configuration (use `.env.example` as a template)
4. Start the development server:
   ```
   npm run dev
   ```

## Production Deployment

To start the server in production mode:

```
npm start
```

## Configuration

Set the following environment variables in your `.env` file:

- `RAPID_API_KEY`: Your API key for basketball data
- `PORT`: Server port (default: 3000)

## Technologies Used

- HTML5, CSS3, JavaScript
- SQLite for data storage
- Express.js for server 