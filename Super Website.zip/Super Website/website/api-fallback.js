// API Fallback for Basketball Website
// This script provides mock data when PHP is not available

// Add this script to index.html before other scripts that depend on API calls
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're in a development environment without PHP
    checkPhpAvailability().then(phpAvailable => {
        if (!phpAvailable) {
            console.log('PHP not available. Using fallback API data.');
            setupFallbackApi();
        }
    });
});

// Check if PHP is available by making a test request
async function checkPhpAvailability() {
    try {
        const response = await fetch('api/test.php');
        return response.ok;
    } catch (error) {
        return false;
    }
}

// Setup the fallback API by intercepting fetch calls
function setupFallbackApi() {
    // Store the original fetch function
    const originalFetch = window.fetch;
    
    // Override the fetch function
    window.fetch = function(url, options) {
        // If the URL contains our API endpoints, intercept and return mock data
        if (typeof url === 'string' && url.includes('api/')) {
            return handleMockApiRequest(url, options);
        }
        
        // Otherwise, use the original fetch
        return originalFetch(url, options);
    };
}

// Handle mock API requests
async function handleMockApiRequest(url, options = {}) {
    console.log(`Intercepted API call to: ${url}`);
    
    // Parse the URL to determine which API endpoint was called
    const endpoint = url.split('/').pop().split('.')[0];
    
    // Get the request method (default to GET)
    const method = options.method || 'GET';
    
    // Get the request body if it exists
    let requestBody = null;
    if (options.body) {
        try {
            requestBody = JSON.parse(options.body);
        } catch (e) {
            console.error('Error parsing request body:', e);
        }
    }
    
    // Handle different API endpoints
    let responseData;
    
    switch (endpoint) {
        case 'auth':
            responseData = handleAuthApi(method, requestBody);
            break;
        case 'players':
            responseData = handlePlayersApi(method, requestBody);
            break;
        case 'tickets':
            responseData = handleTicketsApi(method, requestBody);
            break;
        case 'courts':
            responseData = handleCourtsApi(method, requestBody);
            break;
        default:
            // Return a 404 for unknown endpoints
            return createMockResponse({ error: 'Endpoint not found' }, 404);
    }
    
    // Return a mock response
    return createMockResponse(responseData);
}

// Create a mock Response object
function createMockResponse(data, status = 200) {
    return new Response(JSON.stringify(data), {
        status: status,
        headers: { 'Content-Type': 'application/json' }
    });
}

// Handle authentication API
function handleAuthApi(method, requestBody) {
    if (method === 'POST' && requestBody) {
        if (requestBody.action === 'register') {
            // Mock registration
            return {
                success: true,
                message: 'Registration successful',
                user: {
                    id: Math.floor(Math.random() * 1000),
                    username: requestBody.username,
                    email: requestBody.email
                }
            };
        } else if (requestBody.action === 'login') {
            // Mock login
            return {
                success: true,
                message: 'Login successful',
                user: {
                    id: Math.floor(Math.random() * 1000),
                    username: requestBody.username,
                    email: requestBody.username + '@example.com'
                }
            };
        }
    }
    
    return { success: false, error: 'Invalid request' };
}

// Handle players API
function handlePlayersApi(method) {
    if (method === 'GET') {
        return {
            success: true,
            players: [
                {
                    id: 1,
                    name: 'LeBron James',
                    team: 'Los Angeles Lakers',
                    position: 'Forward',
                    stats: {
                        ppg: 25.7,
                        rpg: 7.9,
                        apg: 10.6
                    },
                    image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=800&q=100'
                },
                {
                    id: 2,
                    name: 'Stephen Curry',
                    team: 'Golden State Warriors',
                    position: 'Guard',
                    stats: {
                        ppg: 29.4,
                        rpg: 5.2,
                        apg: 6.3
                    },
                    image: 'https://images.unsplash.com/photo-1519861531473-9200262188bf?w=800&q=100'
                },
                {
                    id: 3,
                    name: 'Kevin Durant',
                    team: 'Phoenix Suns',
                    position: 'Forward',
                    stats: {
                        ppg: 27.3,
                        rpg: 6.8,
                        apg: 5.0
                    },
                    image: 'https://images.unsplash.com/photo-1504450758481-7338eba7524a?w=800&q=100'
                }
            ]
        };
    }
    
    return { success: false, error: 'Invalid request' };
}

// Handle tickets API
function handleTicketsApi(method, requestBody) {
    if (method === 'GET') {
        // Return available games
        return {
            success: true,
            games: [
                {
                    id: 1,
                    home_team: 'LA Lakers',
                    away_team: 'Chicago Bulls',
                    game_date: '2025-04-15',
                    game_time: '19:30:00',
                    venue: 'Staples Center',
                    tickets_available: 150
                },
                {
                    id: 2,
                    home_team: 'Boston Celtics',
                    away_team: 'Brooklyn Nets',
                    game_date: '2025-04-18',
                    game_time: '20:00:00',
                    venue: 'TD Garden',
                    tickets_available: 200
                },
                {
                    id: 3,
                    home_team: 'Miami Heat',
                    away_team: 'Philadelphia 76ers',
                    game_date: '2025-04-20',
                    game_time: '18:00:00',
                    venue: 'American Airlines Arena',
                    tickets_available: 120
                }
            ]
        };
    } else if (method === 'POST' && requestBody) {
        // Handle ticket booking
        return {
            success: true,
            message: 'Booking successful',
            booking: {
                id: Math.floor(Math.random() * 10000),
                gameId: requestBody.gameId,
                section: requestBody.section,
                tickets: requestBody.tickets,
                totalPrice: requestBody.totalPrice,
                bookingDate: new Date().toISOString()
            }
        };
    }
    
    return { success: false, error: 'Invalid request' };
}

// Handle courts API
function handleCourtsApi(method, requestBody) {
    if (method === 'GET') {
        // Return available courts
        return {
            success: true,
            courts: [
                {
                    id: 1,
                    name: 'Downtown Basketball Court',
                    address: '123 Main St, Anytown, USA',
                    lat: 40.7128,
                    lng: -74.0060,
                    available: true,
                    hourly_rate: 25,
                    amenities: ['Lighting', 'Water Fountain', 'Restrooms']
                },
                {
                    id: 2,
                    name: 'Riverside Park Court',
                    address: '456 Park Ave, Anytown, USA',
                    lat: 40.7282,
                    lng: -73.9942,
                    available: true,
                    hourly_rate: 20,
                    amenities: ['Lighting', 'Parking']
                },
                {
                    id: 3,
                    name: 'Community Center Court',
                    address: '789 Center Blvd, Anytown, USA',
                    lat: 40.7369,
                    lng: -74.0300,
                    available: true,
                    hourly_rate: 30,
                    amenities: ['Indoor', 'Locker Rooms', 'Showers', 'Pro Shop']
                }
            ]
        };
    } else if (method === 'POST' && requestBody) {
        // Handle court booking
        return {
            success: true,
            message: 'Court booking successful',
            booking: {
                id: Math.floor(Math.random() * 10000),
                courtId: requestBody.courtId,
                date: requestBody.date,
                startTime: requestBody.startTime,
                endTime: requestBody.endTime,
                totalPrice: requestBody.totalPrice,
                bookingDate: new Date().toISOString()
            }
        };
    }
    
    return { success: false, error: 'Invalid request' };
}
