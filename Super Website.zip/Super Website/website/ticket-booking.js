// Ticket Booking System for Basketball Games

// Global variables
let availableGames = [];
let selectedGame = null;
let selectedTickets = {
    standard: 0,
    premium: 0,
    vip: 0
};
let selectedSection = null;
let totalPrice = 0;

// Ticket prices
const ticketPrices = {
    standard: 25,
    premium: 50,
    vip: 100
};

// Initialize ticket booking when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeTicketBookingSection();
    loadAvailableGames();
    initializeTicketBookingModal();
});

// Load available games with tickets from API
async function loadAvailableGames() {
    try {
        const response = await fetch('api/tickets.php');
        const data = await response.json();
        
        if (data.success) {
            availableGames = data.games;
            renderAvailableGames();
        } else {
            console.error('Error loading games:', data.error);
        }
    } catch (error) {
        console.error('Error loading games:', error);
        // Fallback to sample data
        availableGames = [
            {
                id: 1,
                home_team: 'LA Lakers',
                away_team: 'Chicago Bulls',
                game_date: '2025-04-15',
                game_time: '19:30:00',
                venue: 'Staples Center',
                tickets_available: 150
            },
            {
                id: 2,
                home_team: 'Boston Celtics',
                away_team: 'Brooklyn Nets',
                game_date: '2025-04-18',
                game_time: '20:00:00',
                venue: 'TD Garden',
                tickets_available: 200
            },
            {
                id: 3,
                home_team: 'Miami Heat',
                away_team: 'Philadelphia 76ers',
                game_date: '2025-04-20',
                game_time: '18:00:00',
                venue: 'American Airlines Arena',
                tickets_available: 120
            }
        ];
        renderAvailableGames();
    }
}

// Initialize the ticket booking section
function initializeTicketBookingSection() {
    const ticketsSection = document.getElementById('ticketsSection');
    if (!ticketsSection) {
        // Create tickets section if it doesn't exist
        const section = document.createElement('section');
        section.id = 'ticketsSection';
        section.className = 'section tickets-section';
        section.innerHTML = `
            <div class="section-header">
                <h2>Basketball Game Tickets</h2>
                <p>Book tickets for upcoming basketball games</p>
            </div>
            
            <div id="availableGames" class="available-games">
                <div class="games-loading">
                    <div class="spinner"></div>
                    <p>Loading available games...</p>
                </div>
            </div>
        `;
        
        // Find where to insert the section (before the courts section if it exists, otherwise before the footer)
        const courtsSection = document.getElementById('courtsSection');
        const footer = document.querySelector('footer');
        
        if (courtsSection) {
            document.body.insertBefore(section, courtsSection);
        } else if (footer) {
            document.body.insertBefore(section, footer);
        } else {
            document.body.appendChild(section);
        }
        
        // Add styles for tickets section
        if (!document.getElementById('ticketsStyles')) {
            const ticketsStyles = `
                .tickets-section {
                    padding: 4rem 2rem;
                    background: var(--dark-bg, #0f0f1e);
                }
                
                .available-games {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 2rem;
                    margin-top: 2rem;
                }
                
                .games-loading {
                    grid-column: 1 / -1;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    height: 200px;
                }
                
                .game-card {
                    background: var(--card-bg, #1a1a2e);
                    border-radius: 15px;
                    overflow: hidden;
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }
                
                .game-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
                }
                
                .game-header {
                    background: linear-gradient(135deg, var(--primary-color, #4361ee), var(--secondary-color, #3a0ca3));
                    padding: 1.5rem;
                    color: white;
                    text-align: center;
                }
                
                .game-teams {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 1rem;
                }
                
                .team {
                    text-align: center;
                    flex: 1;
                }
                
                .team h3 {
                    font-size: 1.2rem;
                    margin-bottom: 0.5rem;
                }
                
                .vs {
                    font-size: 1.2rem;
                    font-weight: 700;
                    margin: 0 1rem;
                }
                
                .game-details {
                    padding: 1.5rem;
                }
                
                .game-info {
                    margin-bottom: 1.5rem;
                }
                
                .game-info p {
                    display: flex;
                    align-items: center;
                    margin-bottom: 0.5rem;
                    color: var(--text-dim, #ccc);
                }
                
                .game-info i {
                    margin-right: 0.5rem;
                    color: var(--primary-color, #4361ee);
                    width: 20px;
                    text-align: center;
                }
                
                .btn-book-tickets {
                    width: 100%;
                    padding: 0.8rem;
                    background: var(--primary-color, #4361ee);
                    color: white;
                    border: none;
                    border-radius: 8px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .btn-book-tickets:hover {
                    background: var(--accent-color, #f72585);
                    transform: translateY(-2px);
                }
                
                .tickets-available {
                    display: inline-block;
                    padding: 0.3rem 0.6rem;
                    background: var(--accent-color, #f72585);
                    color: white;
                    border-radius: 4px;
                    font-size: 0.9rem;
                    margin-top: 0.5rem;
                }
                
                @media (max-width: 768px) {
                    .available-games {
                        grid-template-columns: 1fr;
                    }
                }
            `;
            
            const styleElement = document.createElement('style');
            styleElement.id = 'ticketsStyles';
            styleElement.textContent = ticketsStyles;
            document.head.appendChild(styleElement);
        }
    }
}

function initializeTicketSystem() {
    // Add event listeners to all book ticket buttons
    const bookButtons = document.querySelectorAll('.book-ticket');
    console.log(`Found ${bookButtons.length} book ticket buttons`);
    
    bookButtons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const gameId = this.getAttribute('data-game');
            showTicketBookingModal(gameId);
            return false;
        });
    });
}

function showTicketBookingModal(gameId) {
    // Check if modal exists, if not create it
    let ticketModal = document.getElementById('ticketBookingModal');
    
    if (!ticketModal) {
        // Create modal HTML
        const modalHTML = `
            <div id="ticketBookingModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    <div class="modal-body">
                        <h2 id="game-title">Book Tickets</h2>
                        <div class="game-details" id="gameDetails">
                            <!-- Game details will be inserted here -->
                        </div>
                        <div class="ticket-form">
                            <div class="form-group">
                                <label for="ticketType">Ticket Type</label>
                                <select id="ticketType" required>
                                    <option value="standard">Standard - $50</option>
                                    <option value="premium">Premium - $100</option>
                                    <option value="vip">VIP - $200</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="ticketQuantity">Number of Tickets</label>
                                <input type="number" id="ticketQuantity" min="1" max="10" value="1" required>
                            </div>
                            <div class="form-group">
                                <label>Seating Section</label>
                                <div class="seating-map">
                                    <div class="court-graphic">
                                        <div class="court"></div>
                                    </div>
                                    <div class="seating-options">
                                        <div class="seating-option" data-section="A">
                                            <input type="radio" id="sectionA" name="section" value="A" checked>
                                            <label for="sectionA">Section A</label>
                                        </div>
                                        <div class="seating-option" data-section="B">
                                            <input type="radio" id="sectionB" name="section" value="B">
                                            <label for="sectionB">Section B</label>
                                        </div>
                                        <div class="seating-option" data-section="C">
                                            <input type="radio" id="sectionC" name="section" value="C">
                                            <label for="sectionC">Section C</label>
                                        </div>
                                        <div class="seating-option" data-section="D">
                                            <input type="radio" id="sectionD" name="section" value="D">
                                            <label for="sectionD">Section D</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="price-summary">
                                    <div class="price-row">
                                        <span>Ticket Price:</span>
                                        <span id="ticketPrice">$50.00</span>
                                    </div>
                                    <div class="price-row">
                                        <span>Quantity:</span>
                                        <span id="ticketCount">1</span>
                                    </div>
                                    <div class="price-row total">
                                        <span>Total:</span>
                                        <span id="totalPrice">$50.00</span>
                                    </div>
                                </div>
                            </div>
                            <button id="confirmTicketBtn" class="confirm-ticket-btn">Proceed to Payment</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal to the body
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        ticketModal = document.getElementById('ticketBookingModal');
        
        // Add modal styles if not already added
        if (!document.getElementById('ticketModalStyles')) {
            const modalStyles = `
                #ticketBookingModal {
                    display: none;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.8);
                    z-index: 1000;
                    justify-content: center;
                    align-items: center;
                    overflow-y: auto;
                }
                
                #ticketBookingModal .modal-content {
                    background: var(--card-bg, #1a1a2e);
                    border-radius: 10px;
                    width: 90%;
                    max-width: 600px;
                    padding: 2rem;
                    position: relative;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
                    color: var(--text-light, #fff);
                    margin: 2rem auto;
                }
                
                #ticketBookingModal .close-modal {
                    position: absolute;
                    top: 15px;
                    right: 20px;
                    font-size: 24px;
                    cursor: pointer;
                    color: var(--text-dim, #ccc);
                }
                
                #ticketBookingModal .close-modal:hover {
                    color: var(--accent-color, #f72585);
                }
                
                #ticketBookingModal #game-title {
                    font-size: 1.8rem;
                    margin-bottom: 1rem;
                    color: var(--accent-color, #f72585);
                }
                
                #ticketBookingModal .game-details {
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 8px;
                    padding: 1.5rem;
                    margin-bottom: 1.5rem;
                }
                
                #ticketBookingModal .game-teams {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 1rem;
                }
                
                #ticketBookingModal .team {
                    text-align: center;
                    flex: 1;
                }
                
                #ticketBookingModal .team-logo {
                    width: 60px;
                    height: 60px;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 0.5rem;
                    font-size: 1.5rem;
                }
                
                #ticketBookingModal .versus {
                    font-size: 1.2rem;
                    margin: 0 1rem;
                    color: var(--text-dim, #ccc);
                }
                
                #ticketBookingModal .game-info {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                    margin-top: 1rem;
                }
                
                #ticketBookingModal .info-item {
                    display: flex;
                    align-items: center;
                }
                
                #ticketBookingModal .info-item i {
                    margin-right: 0.5rem;
                    color: var(--primary-color, #4361ee);
                }
                
                #ticketBookingModal .ticket-form {
                    display: grid;
                    gap: 1.5rem;
                }
                
                #ticketBookingModal .form-group {
                    display: grid;
                    gap: 0.5rem;
                }
                
                #ticketBookingModal label {
                    font-size: 0.9rem;
                    color: var(--text-dim, #ccc);
                }
                
                #ticketBookingModal input,
                #ticketBookingModal select {
                    padding: 0.8rem;
                    border-radius: 5px;
                    border: 1px solid var(--card-border, #2a2a4a);
                    background: var(--dark-surface, #121225);
                    color: var(--text-light, #fff);
                    font-size: 1rem;
                }
                
                #ticketBookingModal input:focus,
                #ticketBookingModal select:focus {
                    outline: none;
                    border-color: var(--primary-color, #4361ee);
                }
                
                #ticketBookingModal .seating-map {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                    margin-top: 0.5rem;
                }
                
                #ticketBookingModal .court-graphic {
                    background: rgba(0, 0, 0, 0.3);
                    border-radius: 8px;
                    padding: 1rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                #ticketBookingModal .court {
                    width: 100px;
                    height: 60px;
                    background: rgba(255, 255, 255, 0.1);
                    border: 2px solid var(--primary-color, #4361ee);
                    border-radius: 5px;
                    position: relative;
                }
                
                #ticketBookingModal .court:before {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    width: 30px;
                    height: 30px;
                    border-radius: 50%;
                    border: 2px solid var(--primary-color, #4361ee);
                }
                
                #ticketBookingModal .seating-options {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 0.5rem;
                }
                
                #ticketBookingModal .seating-option {
                    padding: 0.5rem;
                    border-radius: 5px;
                    background: rgba(255, 255, 255, 0.05);
                    cursor: pointer;
                    transition: background 0.3s ease;
                }
                
                #ticketBookingModal .seating-option:hover {
                    background: rgba(255, 255, 255, 0.1);
                }
                
                #ticketBookingModal .seating-option input {
                    margin-right: 0.5rem;
                }
                
                #ticketBookingModal .price-summary {
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 8px;
                    padding: 1rem;
                }
                
                #ticketBookingModal .price-row {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 0.5rem;
                    font-size: 0.9rem;
                    color: var(--text-dim, #ccc);
                }
                
                #ticketBookingModal .price-row.total {
                    margin-top: 0.5rem;
                    padding-top: 0.5rem;
                    border-top: 1px solid rgba(255, 255, 255, 0.1);
                    font-weight: bold;
                    font-size: 1.1rem;
                    color: var(--text-light, #fff);
                }
                
                #ticketBookingModal .confirm-ticket-btn {
                    padding: 0.8rem 1.5rem;
                    background: var(--primary-color, #4361ee);
                    color: white;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: background 0.3s ease, transform 0.2s ease;
                    margin-top: 1rem;
                }
                
                #ticketBookingModal .confirm-ticket-btn:hover {
                    background: var(--accent-color, #f72585);
                    transform: translateY(-2px);
                }
                
                @media (max-width: 768px) {
                    #ticketBookingModal .seating-map,
                    #ticketBookingModal .game-info {
                        grid-template-columns: 1fr;
                    }
                }
            `;
            
            const styleElement = document.createElement('style');
            styleElement.id = 'ticketModalStyles';
            styleElement.textContent = modalStyles;
            document.head.appendChild(styleElement);
        }
        
        // Add close button functionality
        const closeBtn = ticketModal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                ticketModal.style.display = 'none';
            });
        }
        
        // Close when clicking outside the modal
        ticketModal.addEventListener('click', function(e) {
            if (e.target === ticketModal) {
                ticketModal.style.display = 'none';
            }
        });
        
        // Add ticket type change handler
        const ticketType = document.getElementById('ticketType');
        const ticketQuantity = document.getElementById('ticketQuantity');
        const ticketPrice = document.getElementById('ticketPrice');
        const ticketCount = document.getElementById('ticketCount');
        const totalPrice = document.getElementById('totalPrice');
        
        function updatePrices() {
            const prices = {
                'standard': 50,
                'premium': 100,
                'vip': 200
            };
            
            const type = ticketType.value;
            const quantity = parseInt(ticketQuantity.value);
            const price = prices[type] || 50;
            
            ticketPrice.textContent = `$${price.toFixed(2)}`;
            ticketCount.textContent = quantity;
            totalPrice.textContent = `$${(price * quantity).toFixed(2)}`;
        }
        
        if (ticketType) {
            ticketType.addEventListener('change', updatePrices);
        }
        
        if (ticketQuantity) {
            ticketQuantity.addEventListener('input', updatePrices);
        }
        
        // Add section selection highlight
        const seatingSections = document.querySelectorAll('.seating-option');
        seatingSections.forEach(section => {
            section.addEventListener('click', function() {
                const input = this.querySelector('input');
                if (input) {
                    input.checked = true;
                }
            });
        });
        
        // Add booking confirmation functionality
        const confirmBtn = document.getElementById('confirmTicketBtn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', function() {
                const type = ticketType.value;
                const quantity = ticketQuantity.value;
                const section = document.querySelector('input[name="section"]:checked').value;
                const total = totalPrice.textContent;
                
                // In a real app, this would send the booking to a server
                alert(`Tickets booked successfully!\n\nGame: ${getGameName(gameId)}\nTicket Type: ${type.charAt(0).toUpperCase() + type.slice(1)}\nQuantity: ${quantity}\nSection: ${section}\nTotal: ${total}\n\nRedirecting to payment...`);
                ticketModal.style.display = 'none';
            });
        }
    }
    
    // Update game details in the modal
    const gameDetails = document.getElementById('gameDetails');
    if (gameDetails) {
        const gameData = getGameData(gameId);
        
        gameDetails.innerHTML = `
            <div class="game-teams">
                <div class="team">
                    <div class="team-logo">${gameData.homeTeam.charAt(0)}</div>
                    <div class="team-name">${gameData.homeTeam}</div>
                </div>
                <div class="versus">VS</div>
                <div class="team">
                    <div class="team-logo">${gameData.awayTeam.charAt(0)}</div>
                    <div class="team-name">${gameData.awayTeam}</div>
                </div>
            </div>
            <div class="game-info">
                <div class="info-item">
                    <i class="fas fa-calendar"></i>
                    <span>${gameData.date}</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <span>${gameData.time}</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${gameData.venue}</span>
                </div>
                <div class="info-item">
                    <i class="fas fa-ticket-alt"></i>
                    <span>${gameData.ticketsLeft} tickets left</span>
                </div>
            </div>
        `;
    }
    
    // Set the game title in the modal
    const gameTitle = document.getElementById('game-title');
    if (gameTitle) {
        gameTitle.textContent = `Book Tickets: ${getGameName(gameId)}`;
    }
    
    // Show the modal
    ticketModal.style.display = 'flex';
}

// Helper function to get game name from ID
function getGameName(gameId) {
    const gameData = getGameData(gameId);
    return `${gameData.homeTeam} vs ${gameData.awayTeam}`;
}

// Helper function to get game data
function getGameData(gameId) {
    // Mock data - in a real app, this would come from an API or database
    const gameDataMap = {
        'game1': {
            homeTeam: 'Lakers',
            awayTeam: 'Warriors',
            date: 'March 25, 2025',
            time: '7:30 PM',
            venue: 'Staples Center, Los Angeles',
            ticketsLeft: 245
        },
        'game2': {
            homeTeam: 'Celtics',
            awayTeam: 'Nets',
            date: 'March 27, 2025',
            time: '8:00 PM',
            venue: 'TD Garden, Boston',
            ticketsLeft: 189
        },
        'game3': {
            homeTeam: 'Heat',
            awayTeam: 'Bucks',
            date: 'March 30, 2025',
            time: '6:30 PM',
            venue: 'FTX Arena, Miami',
            ticketsLeft: 312
        }
    };
    
    // Return data for the requested game, or a default if not found
    return gameDataMap[gameId] || {
        homeTeam: 'Home Team',
        awayTeam: 'Away Team',
        date: 'TBD',
        time: 'TBD',
        venue: 'TBD',
        ticketsLeft: 0
    };
}

// Render available games in the tickets section
function renderAvailableGames() {
    const availableGamesContainer = document.getElementById('availableGames');
    
    if (availableGames.length === 0) {
        availableGamesContainer.innerHTML = `
            <div class="no-games">
                <p>No games available for booking at the moment.</p>
                <p>Please check back later for upcoming games.</p>
            </div>
        `;
        return;
    }
    
    let gamesHTML = '';
    
    availableGames.forEach(game => {
        const gameDate = new Date(`${game.game_date}T${game.game_time}`);
        const formattedDate = gameDate.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        const formattedTime = gameDate.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        gamesHTML += `
            <div class="game-card" data-game-id="${game.id}">
                <div class="game-header">
                    <div class="game-teams">
                        <div class="team home-team">
                            <h3>${game.home_team}</h3>
                            <span>Home</span>
                        </div>
                        <div class="vs">VS</div>
                        <div class="team away-team">
                            <h3>${game.away_team}</h3>
                            <span>Away</span>
                        </div>
                    </div>
                </div>
                <div class="game-details">
                    <div class="game-info">
                        <p><i class="far fa-calendar-alt"></i> ${formattedDate}</p>
                        <p><i class="far fa-clock"></i> ${formattedTime}</p>
                        <p><i class="fas fa-map-marker-alt"></i> ${game.venue}</p>
                        <p class="tickets-available">
                            <i class="fas fa-ticket-alt"></i> ${game.tickets_available} tickets available
                        </p>
                    </div>
                    <button class="btn-book-tickets" onclick="openTicketBookingModal(${game.id})">
                        Book Tickets
                    </button>
                </div>
            </div>
        `;
    });
    
    availableGamesContainer.innerHTML = gamesHTML;
}

// Initialize the ticket booking modal
function initializeTicketBookingModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('ticketBookingModal')) {
        const modal = document.createElement('div');
        modal.id = 'ticketBookingModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Book Tickets</h2>
                    <span class="close-modal">&times;</span>
                </div>
                <div class="modal-body">
                    <div id="gameDetails" class="game-details-modal">
                        <!-- Game details will be populated dynamically -->
                    </div>
                    
                    <div class="booking-steps">
                        <div class="step active" id="step1">
                            <h3>1. Select Ticket Type</h3>
                            <div class="ticket-types">
                                <div class="ticket-type">
                                    <div class="ticket-info">
                                        <h4>Standard</h4>
                                        <p>Regular seating with good view</p>
                                        <p class="ticket-price">$${ticketPrices.standard}</p>
                                    </div>
                                    <div class="ticket-quantity">
                                        <button class="decrease-btn" onclick="updateTicketQuantity('standard', -1)">-</button>
                                        <span id="standardQuantity">0</span>
                                        <button class="increase-btn" onclick="updateTicketQuantity('standard', 1)">+</button>
                                    </div>
                                </div>
                                
                                <div class="ticket-type">
                                    <div class="ticket-info">
                                        <h4>Premium</h4>
                                        <p>Better seating with excellent view</p>
                                        <p class="ticket-price">$${ticketPrices.premium}</p>
                                    </div>
                                    <div class="ticket-quantity">
                                        <button class="decrease-btn" onclick="updateTicketQuantity('premium', -1)">-</button>
                                        <span id="premiumQuantity">0</span>
                                        <button class="increase-btn" onclick="updateTicketQuantity('premium', 1)">+</button>
                                    </div>
                                </div>
                                
                                <div class="ticket-type">
                                    <div class="ticket-info">
                                        <h4>VIP</h4>
                                        <p>Premium seating with the best view</p>
                                        <p class="ticket-price">$${ticketPrices.vip}</p>
                                    </div>
                                    <div class="ticket-quantity">
                                        <button class="decrease-btn" onclick="updateTicketQuantity('vip', -1)">-</button>
                                        <span id="vipQuantity">0</span>
                                        <button class="increase-btn" onclick="updateTicketQuantity('vip', 1)">+</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="step-navigation">
                                <button class="btn-next" onclick="goToStep(2)" disabled id="nextToStep2">Next: Select Seating</button>
                            </div>
                        </div>
                        
                        <div class="step" id="step2">
                            <h3>2. Select Seating Section</h3>
                            <div class="seating-map">
                                <div class="court-container">
                                    <div class="basketball-court">
                                        <div class="court-outline"></div>
                                        <div class="center-circle"></div>
                                        <div class="three-point-line left"></div>
                                        <div class="three-point-line right"></div>
                                        <div class="free-throw-line left"></div>
                                        <div class="free-throw-line right"></div>
                                        <div class="backboard left"></div>
                                        <div class="backboard right"></div>
                                        <div class="rim left"></div>
                                        <div class="rim right"></div>
                                    </div>
                                </div>
                                
                                <div class="seating-sections">
                                    <div class="section-row">
                                        <div class="section standard" data-section="A1" onclick="selectSection('A1', 'standard')">A1</div>
                                        <div class="section standard" data-section="A2" onclick="selectSection('A2', 'standard')">A2</div>
                                        <div class="section standard" data-section="A3" onclick="selectSection('A3', 'standard')">A3</div>
                                    </div>
                                    <div class="section-row">
                                        <div class="section premium" data-section="B1" onclick="selectSection('B1', 'premium')">B1</div>
                                        <div class="section premium" data-section="B2" onclick="selectSection('B2', 'premium')">B2</div>
                                        <div class="section premium" data-section="B3" onclick="selectSection('B3', 'premium')">B3</div>
                                    </div>
                                    <div class="section-row">
                                        <div class="section vip" data-section="C1" onclick="selectSection('C1', 'vip')">C1</div>
                                        <div class="section vip" data-section="C2" onclick="selectSection('C2', 'vip')">C2</div>
                                        <div class="section vip" data-section="C3" onclick="selectSection('C3', 'vip')">C3</div>
                                    </div>
                                </div>
                                
                                <div class="section-legend">
                                    <div class="legend-item">
                                        <div class="legend-color standard"></div>
                                        <span>Standard</span>
                                    </div>
                                    <div class="legend-item">
                                        <div class="legend-color premium"></div>
                                        <span>Premium</span>
                                    </div>
                                    <div class="legend-item">
                                        <div class="legend-color vip"></div>
                                        <span>VIP</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="selected-section-info">
                                <p>Selected Section: <span id="selectedSectionDisplay">None</span></p>
                            </div>
                            
                            <div class="step-navigation">
                                <button class="btn-prev" onclick="goToStep(1)">Back: Ticket Selection</button>
                                <button class="btn-next" onclick="goToStep(3)" disabled id="nextToStep3">Next: Checkout</button>
                            </div>
                        </div>
                        
                        <div class="step" id="step3">
                            <h3>3. Checkout</h3>
                            <div class="checkout-summary">
                                <h4>Order Summary</h4>
                                <div class="summary-item">
                                    <span>Game:</span>
                                    <span id="summaryGame"></span>
                                </div>
                                <div class="summary-item">
                                    <span>Date & Time:</span>
                                    <span id="summaryDateTime"></span>
                                </div>
                                <div class="summary-item">
                                    <span>Venue:</span>
                                    <span id="summaryVenue"></span>
                                </div>
                                <div class="summary-item">
                                    <span>Section:</span>
                                    <span id="summarySection"></span>
                                </div>
                                <div class="summary-tickets" id="summaryTickets">
                                    <!-- Ticket summary will be populated dynamically -->
                                </div>
                                <div class="summary-total">
                                    <span>Total:</span>
                                    <span id="summaryTotal">$0.00</span>
                                </div>
                            </div>
                            
                            <div class="checkout-form">
                                <h4>Contact Information</h4>
                                <form id="checkoutForm">
                                    <div class="form-group">
                                        <label for="fullName">Full Name</label>
                                        <input type="text" id="fullName" name="fullName" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" id="email" name="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <input type="tel" id="phone" name="phone" required>
                                    </div>
                                    
                                    <div class="payment-info">
                                        <h4>Payment Information</h4>
                                        <div class="form-group">
                                            <label for="cardNumber">Card Number</label>
                                            <input type="text" id="cardNumber" name="cardNumber" placeholder="XXXX XXXX XXXX XXXX" required>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group">
                                                <label for="expiryDate">Expiry Date</label>
                                                <input type="text" id="expiryDate" name="expiryDate" placeholder="MM/YY" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="cvv">CVV</label>
                                                <input type="text" id="cvv" name="cvv" placeholder="XXX" required>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="step-navigation">
                                <button class="btn-prev" onclick="goToStep(2)">Back: Seating Selection</button>
                                <button class="btn-complete" onclick="completeBooking()">Complete Booking</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // Add modal styles
        if (!document.getElementById('ticketModalStyles')) {
            const modalStyles = `
                .modal {
                    display: none;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.7);
                    z-index: 1000;
                    overflow-y: auto;
                }
                
                .modal-content {
                    background-color: var(--card-bg, #1a1a2e);
                    margin: 5% auto;
                    width: 90%;
                    max-width: 900px;
                    border-radius: 15px;
                    box-shadow: 0 5px 30px rgba(0, 0, 0, 0.3);
                    animation: modalFadeIn 0.3s ease;
                }
                
                @keyframes modalFadeIn {
                    from { opacity: 0; transform: translateY(-50px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                
                .modal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1.5rem;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                .modal-header h2 {
                    margin: 0;
                    color: white;
                }
                
                .close-modal {
                    color: var(--text-dim, #ccc);
                    font-size: 2rem;
                    cursor: pointer;
                    transition: color 0.3s ease;
                }
                
                .close-modal:hover {
                    color: var(--accent-color, #f72585);
                }
                
                .modal-body {
                    padding: 1.5rem;
                }
                
                .game-details-modal {
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    padding: 1.5rem;
                    margin-bottom: 2rem;
                }
                
                .game-title {
                    font-size: 1.5rem;
                    margin-bottom: 1rem;
                    text-align: center;
                }
                
                .game-meta {
                    display: flex;
                    flex-wrap: wrap;
                    justify-content: space-around;
                    margin-bottom: 1rem;
                }
                
                .game-meta-item {
                    display: flex;
                    align-items: center;
                    margin: 0.5rem;
                    color: var(--text-dim, #ccc);
                }
                
                .game-meta-item i {
                    margin-right: 0.5rem;
                    color: var(--primary-color, #4361ee);
                }
                
                .booking-steps {
                    position: relative;
                }
                
                .step {
                    display: none;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                }
                
                .step.active {
                    display: block;
                    opacity: 1;
                }
                
                .step h3 {
                    margin-top: 0;
                    margin-bottom: 1.5rem;
                    color: var(--primary-color, #4361ee);
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                    padding-bottom: 0.5rem;
                }
                
                .ticket-types {
                    display: flex;
                    flex-direction: column;
                    gap: 1.5rem;
                    margin-bottom: 2rem;
                }
                
                .ticket-type {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    padding: 1.5rem;
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }
                
                .ticket-type:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                }
                
                .ticket-info h4 {
                    margin-top: 0;
                    margin-bottom: 0.5rem;
                    color: white;
                }
                
                .ticket-info p {
                    margin: 0.3rem 0;
                    color: var(--text-dim, #ccc);
                }
                
                .ticket-price {
                    font-weight: 700;
                    color: var(--accent-color, #f72585) !important;
                    font-size: 1.2rem;
                    margin-top: 0.5rem !important;
                }
                
                .ticket-quantity {
                    display: flex;
                    align-items: center;
                }
                
                .decrease-btn, .increase-btn {
                    width: 36px;
                    height: 36px;
                    border-radius: 50%;
                    border: none;
                    background: var(--primary-color, #4361ee);
                    color: white;
                    font-size: 1.2rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .decrease-btn:hover, .increase-btn:hover {
                    background: var(--accent-color, #f72585);
                    transform: scale(1.1);
                }
                
                .decrease-btn:disabled, .increase-btn:disabled {
                    background: #555;
                    cursor: not-allowed;
                    transform: none;
                }
                
                .ticket-quantity span {
                    margin: 0 1rem;
                    font-size: 1.2rem;
                    font-weight: 700;
                    min-width: 30px;
                    text-align: center;
                }
                
                .step-navigation {
                    display: flex;
                    justify-content: flex-end;
                    margin-top: 2rem;
                }
                
                .btn-prev, .btn-next, .btn-complete {
                    padding: 0.8rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .btn-prev {
                    background: transparent;
                    color: var(--text-dim, #ccc);
                    border: 1px solid var(--text-dim, #ccc);
                    margin-right: 1rem;
                }
                
                .btn-prev:hover {
                    background: rgba(255, 255, 255, 0.1);
                    color: white;
                }
                
                .btn-next, .btn-complete {
                    background: var(--primary-color, #4361ee);
                    color: white;
                }
                
                .btn-next:hover, .btn-complete:hover {
                    background: var(--accent-color, #f72585);
                    transform: translateY(-3px);
                }
                
                .btn-next:disabled {
                    background: #555;
                    cursor: not-allowed;
                    transform: none;
                }
                
                .btn-complete {
                    background: var(--accent-color, #f72585);
                }
                
                .seating-map {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    margin-bottom: 2rem;
                }
                
                .court-container {
                    width: 100%;
                    max-width: 500px;
                    margin-bottom: 2rem;
                }
                
                .basketball-court {
                    position: relative;
                    width: 100%;
                    padding-top: 60%;
                    background: #8B4513;
                    border-radius: 10px;
                    overflow: hidden;
                }
                
                .court-outline {
                    position: absolute;
                    top: 5%;
                    left: 5%;
                    width: 90%;
                    height: 90%;
                    border: 2px solid rgba(255, 255, 255, 0.7);
                    border-radius: 5px;
                }
                
                .center-circle {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    width: 20%;
                    height: 20%;
                    border: 2px solid rgba(255, 255, 255, 0.7);
                    border-radius: 50%;
                }
                
                .three-point-line {
                    position: absolute;
                    width: 30%;
                    height: 40%;
                    border: 2px solid rgba(255, 255, 255, 0.7);
                    border-radius: 50% 0 0 50%;
                }
                
                .three-point-line.left {
                    top: 30%;
                    left: 0;
                }
                
                .three-point-line.right {
                    top: 30%;
                    right: 0;
                    transform: scaleX(-1);
                }
                
                .free-throw-line {
                    position: absolute;
                    width: 15%;
                    height: 0;
                    border-top: 2px solid rgba(255, 255, 255, 0.7);
                }
                
                .free-throw-line.left {
                    top: 50%;
                    left: 5%;
                }
                
                .free-throw-line.right {
                    top: 50%;
                    right: 5%;
                }
                
                .backboard {
                    position: absolute;
                    width: 10%;
                    height: 1%;
                    background: white;
                }
                
                .backboard.left {
                    top: 50%;
                    left: 0;
                }
                
                .backboard.right {
                    top: 50%;
                    right: 0;
                }
                
                .rim {
                    position: absolute;
                    width: 5%;
                    height: 5%;
                    border: 2px solid orange;
                    border-radius: 50%;
                }
                
                .rim.left {
                    top: 47.5%;
                    left: 5%;
                }
                
                .rim.right {
                    top: 47.5%;
                    right: 5%;
                }
                
                .seating-sections {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                    width: 100%;
                    max-width: 500px;
                }
                
                .section-row {
                    display: flex;
                    justify-content: space-between;
                    gap: 1rem;
                }
                
                .section {
                    flex: 1;
                    padding: 1rem;
                    text-align: center;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .section:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                }
                
                .section.standard {
                    background: rgba(67, 97, 238, 0.3);
                    border: 2px solid var(--primary-color, #4361ee);
                }
                
                .section.premium {
                    background: rgba(58, 12, 163, 0.3);
                    border: 2px solid var(--secondary-color, #3a0ca3);
                }
                
                .section.vip {
                    background: rgba(247, 37, 133, 0.3);
                    border: 2px solid var(--accent-color, #f72585);
                }
                
                .section.selected {
                    transform: scale(1.05);
                    box-shadow: 0 0 20px rgba(255, 255, 255, 0.3);
                }
                
                .section-legend {
                    display: flex;
                    justify-content: center;
                    gap: 2rem;
                    margin-top: 1rem;
                }
                
                .legend-item {
                    display: flex;
                    align-items: center;
                }
                
                .legend-color {
                    width: 20px;
                    height: 20px;
                    border-radius: 4px;
                    margin-right: 0.5rem;
                }
                
                .legend-color.standard {
                    background: var(--primary-color, #4361ee);
                }
                
                .legend-color.premium {
                    background: var(--secondary-color, #3a0ca3);
                }
                
                .legend-color.vip {
                    background: var(--accent-color, #f72585);
                }
                
                .selected-section-info {
                    text-align: center;
                    margin-top: 1rem;
                    font-weight: 700;
                }
                
                .checkout-summary {
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    padding: 1.5rem;
                    margin-bottom: 2rem;
                }
                
                .checkout-summary h4 {
                    margin-top: 0;
                    margin-bottom: 1rem;
                    color: white;
                }
                
                .summary-item {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 0.5rem;
                    padding-bottom: 0.5rem;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
                
                .summary-tickets {
                    margin: 1rem 0;
                }
                
                .summary-ticket-item {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 0.5rem;
                }
                
                .summary-total {
                    display: flex;
                    justify-content: space-between;
                    font-weight: 700;
                    font-size: 1.2rem;
                    margin-top: 1rem;
                    padding-top: 1rem;
                    border-top: 2px solid rgba(255, 255, 255, 0.2);
                }
                
                .checkout-form {
                    margin-bottom: 2rem;
                }
                
                .checkout-form h4 {
                    margin-top: 0;
                    margin-bottom: 1rem;
                    color: white;
                }
                
                .form-group {
                    margin-bottom: 1.5rem;
                }
                
                .form-row {
                    display: flex;
                    gap: 1rem;
                }
                
                .form-row .form-group {
                    flex: 1;
                }
                
                label {
                    display: block;
                    margin-bottom: 0.5rem;
                    color: var(--text-dim, #ccc);
                }
                
                input[type="text"],
                input[type="email"],
                input[type="tel"] {
                    width: 100%;
                    padding: 0.8rem;
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    border-radius: 8px;
                    background: rgba(0, 0, 0, 0.2);
                    color: white;
                    transition: border-color 0.3s ease;
                }
                
                input[type="text"]:focus,
                input[type="email"]:focus,
                input[type="tel"]:focus {
                    border-color: var(--primary-color, #4361ee);
                    outline: none;
                }
                
                .payment-info {
                    margin-top: 2rem;
                }
                
                @media (max-width: 768px) {
                    .ticket-type {
                        flex-direction: column;
                        align-items: flex-start;
                    }
                    
                    .ticket-quantity {
                        margin-top: 1rem;
                    }
                    
                    .form-row {
                        flex-direction: column;
                    }
                    
                    .section-row {
                        flex-direction: column;
                    }
                }
            `;
            
            const styleElement = document.createElement('style');
            styleElement.id = 'ticketModalStyles';
            styleElement.textContent = modalStyles;
            document.head.appendChild(styleElement);
        }
        
        // Add event listeners for modal
        const closeModalBtn = document.querySelector('.close-modal');
        closeModalBtn.addEventListener('click', closeTicketBookingModal);
        
        // Close modal when clicking outside of it
        window.addEventListener('click', (event) => {
            const modal = document.getElementById('ticketBookingModal');
            if (event.target === modal) {
                closeTicketBookingModal();
            }
        });
    }
}

// Open the ticket booking modal with the selected game
function openTicketBookingModal(gameId) {
    // Reset ticket selection
    selectedTickets = {
        standard: 0,
        premium: 0,
        vip: 0
    };
    selectedSection = null;
    totalPrice = 0;
    
    // Find the selected game
    selectedGame = availableGames.find(game => game.id === gameId);
    
    if (!selectedGame) {
        console.error('Game not found with ID:', gameId);
        return;
    }
    
    // Update game details in modal
    const gameDetailsElement = document.getElementById('gameDetails');
    const gameDate = new Date(`${selectedGame.game_date}T${selectedGame.game_time}`);
    const formattedDate = gameDate.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const formattedTime = gameDate.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    gameDetailsElement.innerHTML = `
        <h3 class="game-title">${selectedGame.home_team} vs ${selectedGame.away_team}</h3>
        <div class="game-meta">
            <div class="game-meta-item">
                <i class="far fa-calendar-alt"></i>
                <span>${formattedDate}</span>
            </div>
            <div class="game-meta-item">
                <i class="far fa-clock"></i>
                <span>${formattedTime}</span>
            </div>
            <div class="game-meta-item">
                <i class="fas fa-map-marker-alt"></i>
                <span>${selectedGame.venue}</span>
            </div>
            <div class="game-meta-item">
                <i class="fas fa-ticket-alt"></i>
                <span>${selectedGame.tickets_available} tickets available</span>
            </div>
        </div>
    `;
    
    // Reset ticket quantities
    document.getElementById('standardQuantity').textContent = '0';
    document.getElementById('premiumQuantity').textContent = '0';
    document.getElementById('vipQuantity').textContent = '0';
    
    // Reset section selection
    document.getElementById('selectedSectionDisplay').textContent = 'None';
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('selected');
    });
    
    // Disable next buttons
    document.getElementById('nextToStep2').disabled = true;
    document.getElementById('nextToStep3').disabled = true;
    
    // Show first step
    goToStep(1);
    
    // Show modal
    const modal = document.getElementById('ticketBookingModal');
    modal.style.display = 'block';
}

// Close the ticket booking modal
function closeTicketBookingModal() {
    const modal = document.getElementById('ticketBookingModal');
    modal.style.display = 'none';
}

// Update ticket quantity
function updateTicketQuantity(type, change) {
    // Check if the ticket type exists
    if (!ticketPrices[type]) {
        console.error('Invalid ticket type:', type);
        return;
    }
    
    // Update quantity
    const newQuantity = selectedTickets[type] + change;
    
    // Ensure quantity is not negative
    if (newQuantity < 0) {
        return;
    }
    
    // Ensure total tickets don't exceed available tickets
    const totalTickets = Object.values(selectedTickets).reduce((sum, qty) => sum + qty, 0) + change;
    if (totalTickets > selectedGame.tickets_available) {
        alert(`Sorry, only ${selectedGame.tickets_available} tickets are available for this game.`);
        return;
    }
    
    // Update selected tickets
    selectedTickets[type] = newQuantity;
    
    // Update UI
    document.getElementById(`${type}Quantity`).textContent = newQuantity;
    
    // Calculate total price
    calculateTotalPrice();
    
    // Enable/disable next button
    const totalSelectedTickets = Object.values(selectedTickets).reduce((sum, qty) => sum + qty, 0);
    document.getElementById('nextToStep2').disabled = totalSelectedTickets === 0;
}

// Calculate total price
function calculateTotalPrice() {
    totalPrice = 0;
    
    for (const [type, quantity] of Object.entries(selectedTickets)) {
        totalPrice += ticketPrices[type] * quantity;
    }
    
    return totalPrice;
}

// Select a seating section
function selectSection(sectionId, type) {
    // Check if the user has selected tickets of this type
    if (selectedTickets[type] === 0) {
        alert(`Please select at least one ${type} ticket before choosing a ${type} section.`);
        return;
    }
    
    // Update selected section
    selectedSection = {
        id: sectionId,
        type: type
    };
    
    // Update UI
    document.getElementById('selectedSectionDisplay').textContent = sectionId;
    
    // Remove selected class from all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('selected');
    });
    
    // Add selected class to the chosen section
    const selectedSectionElement = document.querySelector(`.section[data-section="${sectionId}"]`);
    if (selectedSectionElement) {
        selectedSectionElement.classList.add('selected');
    }
    
    // Enable next button
    document.getElementById('nextToStep3').disabled = false;
    
    // Update checkout summary
    updateCheckoutSummary();
}

// Update checkout summary
function updateCheckoutSummary() {
    if (!selectedGame || !selectedSection) {
        return;
    }
    
    // Format date and time
    const gameDate = new Date(`${selectedGame.game_date}T${selectedGame.game_time}`);
    const formattedDate = gameDate.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    const formattedTime = gameDate.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Update summary elements
    document.getElementById('summaryGame').textContent = `${selectedGame.home_team} vs ${selectedGame.away_team}`;
    document.getElementById('summaryDateTime').textContent = `${formattedDate} at ${formattedTime}`;
    document.getElementById('summaryVenue').textContent = selectedGame.venue;
    document.getElementById('summarySection').textContent = selectedSection.id;
    
    // Update tickets summary
    let ticketsHTML = '';
    let totalPrice = 0;
    
    for (const [type, quantity] of Object.entries(selectedTickets)) {
        if (quantity > 0) {
            const price = ticketPrices[type] * quantity;
            totalPrice += price;
            
            ticketsHTML += `
                <div class="summary-ticket-item">
                    <span>${quantity} x ${type.charAt(0).toUpperCase() + type.slice(1)} Ticket${quantity > 1 ? 's' : ''}</span>
                    <span>$${price.toFixed(2)}</span>
                </div>
            `;
        }
    }
    
    document.getElementById('summaryTickets').innerHTML = ticketsHTML;
    document.getElementById('summaryTotal').textContent = `$${totalPrice.toFixed(2)}`;
}

// Navigate between steps
function goToStep(stepNumber) {
    // Hide all steps
    const steps = document.querySelectorAll('.step');
    steps.forEach(step => {
        step.classList.remove('active');
    });
    
    // Show the selected step
    const selectedStep = document.getElementById(`step${stepNumber}`);
    if (selectedStep) {
        selectedStep.classList.add('active');
    }
    
    // If going to step 3, update checkout summary
    if (stepNumber === 3) {
        updateCheckoutSummary();
    }
}

// Complete the booking
async function completeBooking() {
    // Validate form
    const form = document.getElementById('checkoutForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }
    
    // Get form data
    const formData = {
        fullName: document.getElementById('fullName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        cardNumber: document.getElementById('cardNumber').value,
        expiryDate: document.getElementById('expiryDate').value,
        cvv: document.getElementById('cvv').value
    };
    
    // Create booking data
    const bookingData = {
        gameId: selectedGame.id,
        section: selectedSection.id,
        tickets: selectedTickets,
        totalPrice: calculateTotalPrice(),
        customer: formData
    };
    
    try {
        // Show loading state
        const completeBtn = document.querySelector('.btn-complete');
        const originalText = completeBtn.textContent;
        completeBtn.disabled = true;
        completeBtn.textContent = 'Processing...';
        
        // Send booking request to server
        const response = await fetch('api/tickets.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Show success message
            alert('Booking successful! Your tickets have been reserved.');
            
            // Close modal
            closeTicketBookingModal();
            
            // Reload available games
            loadAvailableGames();
        } else {
            // Show error message
            alert(`Booking failed: ${data.error}`);
            
            // Reset button
            completeBtn.disabled = false;
            completeBtn.textContent = originalText;
        }
    } catch (error) {
        console.error('Error completing booking:', error);
        alert('An error occurred while processing your booking. Please try again later.');
        
        // Reset button
        const completeBtn = document.querySelector('.btn-complete');
        completeBtn.disabled = false;
        completeBtn.textContent = 'Complete Booking';
    }
}
