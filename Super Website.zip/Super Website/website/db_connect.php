<?php
// Database connection settings
$host = "localhost";
$username = "root";
$password = "";
$database = "basketball_hub";

// Create connection
$conn = new mysqli($host, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) !== TRUE) {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($database);

// Create users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating users table: " . $conn->error;
}

// Create players table
$sql = "CREATE TABLE IF NOT EXISTS players (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    team VARCHAR(100) NOT NULL,
    position VARCHAR(50),
    points_per_game FLOAT,
    rebounds_per_game FLOAT,
    assists_per_game FLOAT,
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating players table: " . $conn->error;
}

// Create games table
$sql = "CREATE TABLE IF NOT EXISTS games (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    home_team VARCHAR(100) NOT NULL,
    away_team VARCHAR(100) NOT NULL,
    home_score INT(11) DEFAULT 0,
    away_score INT(11) DEFAULT 0,
    game_date DATE NOT NULL,
    game_time TIME NOT NULL,
    venue VARCHAR(255),
    tickets_available INT(11) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating games table: " . $conn->error;
}

// Create tickets table
$sql = "CREATE TABLE IF NOT EXISTS tickets (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    game_id INT(11) NOT NULL,
    user_id INT(11) NOT NULL,
    ticket_type ENUM('standard', 'premium', 'vip') NOT NULL,
    quantity INT(11) NOT NULL,
    section VARCHAR(10) NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (game_id) REFERENCES games(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating tickets table: " . $conn->error;
}

// Create court bookings table
$sql = "CREATE TABLE IF NOT EXISTS court_bookings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    court_id VARCHAR(50) NOT NULL,
    user_id INT(11) NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    num_players INT(11) DEFAULT 1,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating court_bookings table: " . $conn->error;
}

// Create user_favorites table
$sql = "CREATE TABLE IF NOT EXISTS user_favorites (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    player_id INT(11) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (player_id) REFERENCES players(id),
    UNIQUE KEY user_player (user_id, player_id)
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creating user_favorites table: " . $conn->error;
}

// Return connection for use in other files
return $conn;
?>
