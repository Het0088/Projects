// This script fixes click issues on team cards and navigation
document.addEventListener('DOMContentLoaded', function() {
    console.log("Click fix script loaded!");
    
    // Fix team cards
    fixTeamCards();
    
    // Fix navigation links
    fixNavigationLinks();
    
    // Fix book ticket buttons
    fixBookButtons();
});

function fixTeamCards() {
    const teamCards = document.querySelectorAll('.team-card');
    console.log(`Found ${teamCards.length} team cards`);
    
    teamCards.forEach(card => {
        // Remove the card from DOM temporarily
        const parent = card.parentNode;
        const clone = card.cloneNode(true);
        parent.replaceChild(clone, card);
        
        // Make sure the overlay is properly positioned
        const overlay = clone.querySelector('.team-overlay');
        if (overlay) {
            overlay.style.position = 'absolute';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100%';
            overlay.style.height = '100%';
            overlay.style.display = 'flex';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 0.3s ease';
            overlay.style.background = 'rgba(0, 0, 0, 0.7)';
            overlay.style.zIndex = '2';
        }
        
        // Ensure card has proper styling
        clone.style.position = 'relative';
        clone.style.overflow = 'hidden';
        clone.style.cursor = 'pointer';
        clone.style.zIndex = '1';
        clone.style.pointerEvents = 'auto';
        
        // Add hover effect
        clone.addEventListener('mouseenter', function() {
            const overlay = this.querySelector('.team-overlay');
            if (overlay) overlay.style.opacity = '1';
        });
        
        clone.addEventListener('mouseleave', function() {
            const overlay = this.querySelector('.team-overlay');
            if (overlay) overlay.style.opacity = '0';
        });
        
        // Add click event
        clone.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const teamId = this.getAttribute('data-team');
            console.log("Team card clicked:", teamId);
            
            if (teamId) {
                // Show team details in a modal
                showTeamDetails(teamId);
            }
            
            return false;
        });
        
        // Make the view details button clickable too
        const viewDetailsBtn = clone.querySelector('.view-details');
        if (viewDetailsBtn) {
            viewDetailsBtn.style.cursor = 'pointer';
            viewDetailsBtn.style.zIndex = '3';
            viewDetailsBtn.style.position = 'relative';
            viewDetailsBtn.style.pointerEvents = 'auto';
            
            viewDetailsBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const teamId = clone.getAttribute('data-team');
                console.log("View details clicked for team:", teamId);
                
                if (teamId) {
                    // Show team details in a modal
                    showTeamDetails(teamId);
                }
                
                return false;
            });
        }
    });
}

// Function to show team details
function showTeamDetails(teamId) {
    // Check if a team modal exists, if not create one
    let teamModal = document.querySelector('.team-modal');
    
    if (!teamModal) {
        // Create modal HTML
        const modalHTML = `
            <div class="team-modal">
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    <div class="modal-body">
                        <h2 id="team-name"></h2>
                        <p id="team-description"></p>
                        <div id="team-stats"></div>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal to the body
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        teamModal = document.querySelector('.team-modal');
        
        // Add modal styles
        const modalStyles = `
            .team-modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.8);
                z-index: 1000;
                justify-content: center;
                align-items: center;
            }
            
            .team-modal .modal-content {
                background: var(--card-bg, #1a1a2e);
                border-radius: 10px;
                width: 90%;
                max-width: 600px;
                padding: 2rem;
                position: relative;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
                color: var(--text-light, #fff);
            }
            
            .team-modal .close-modal {
                position: absolute;
                top: 15px;
                right: 20px;
                font-size: 24px;
                cursor: pointer;
                color: var(--text-dim, #ccc);
            }
            
            .team-modal .close-modal:hover {
                color: var(--accent-color, #f72585);
            }
            
            .team-modal #team-name {
                font-size: 2rem;
                margin-bottom: 1rem;
                color: var(--accent-color, #f72585);
            }
            
            .team-modal #team-description {
                margin-bottom: 1.5rem;
                line-height: 1.6;
            }
            
            .team-modal #team-stats {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                gap: 1rem;
                margin-top: 2rem;
            }
            
            .team-modal .stat-card {
                background: rgba(255, 255, 255, 0.1);
                padding: 1rem;
                border-radius: 8px;
                text-align: center;
            }
            
            .team-modal .stat-value {
                font-size: 1.5rem;
                font-weight: bold;
                color: var(--primary-color, #4361ee);
            }
            
            .team-modal .stat-label {
                font-size: 0.9rem;
                color: var(--text-dim, #ccc);
                margin-top: 0.5rem;
            }
        `;
        
        // Add styles to head
        const styleElement = document.createElement('style');
        styleElement.textContent = modalStyles;
        document.head.appendChild(styleElement);
        
        // Add close button functionality
        const closeBtn = teamModal.querySelector('.close-modal');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                teamModal.style.display = 'none';
            });
        }
        
        // Close when clicking outside the modal
        teamModal.addEventListener('click', function(e) {
            if (e.target === teamModal) {
                teamModal.style.display = 'none';
            }
        });
    }
    
    // Populate modal with team data
    const teamName = teamModal.querySelector('#team-name');
    const teamDescription = teamModal.querySelector('#team-description');
    const teamStats = teamModal.querySelector('#team-stats');
    
    // Set team data based on teamId
    const teamData = getTeamData(teamId);
    
    if (teamName) teamName.textContent = teamData.name;
    if (teamDescription) teamDescription.textContent = teamData.description;
    
    if (teamStats) {
        teamStats.innerHTML = '';
        
        // Add stats
        for (const [label, value] of Object.entries(teamData.stats)) {
            const statCard = document.createElement('div');
            statCard.className = 'stat-card';
            statCard.innerHTML = `
                <div class="stat-value">${value}</div>
                <div class="stat-label">${label}</div>
            `;
            teamStats.appendChild(statCard);
        }
    }
    
    // Show the modal
    teamModal.style.display = 'flex';
}

// Function to get team data
function getTeamData(teamId) {
    // Mock data - in a real app, this would come from an API or database
    const teamDataMap = {
        'warriors': {
            name: 'Golden State Warriors',
            description: 'The Golden State Warriors are an American professional basketball team based in San Francisco. The Warriors compete in the National Basketball Association (NBA), as a member of the league\'s Western Conference Pacific Division.',
            stats: {
                'Championships': 7,
                'Conference Titles': 12,
                'Division Titles': 12,
                'Win Percentage': '.532'
            }
        },
        'lakers': {
            name: 'Los Angeles Lakers',
            description: 'The Los Angeles Lakers are an American professional basketball team based in Los Angeles. The Lakers compete in the National Basketball Association (NBA) as a member of the league\'s Western Conference Pacific Division.',
            stats: {
                'Championships': 17,
                'Conference Titles': 19,
                'Division Titles': 33,
                'Win Percentage': '.596'
            }
        },
        'celtics': {
            name: 'Boston Celtics',
            description: 'The Boston Celtics are an American professional basketball team based in Boston. The Celtics compete in the National Basketball Association (NBA) as a member of the league\'s Eastern Conference Atlantic Division.',
            stats: {
                'Championships': 17,
                'Conference Titles': 22,
                'Division Titles': 32,
                'Win Percentage': '.590'
            }
        },
        'nets': {
            name: 'Brooklyn Nets',
            description: 'The Brooklyn Nets are an American professional basketball team based in the New York City borough of Brooklyn. The Nets compete in the National Basketball Association (NBA) as a member of the league\'s Eastern Conference Atlantic Division.',
            stats: {
                'Championships': 0,
                'Conference Titles': 2,
                'Division Titles': 5,
                'Win Percentage': '.442'
            }
        },
        'heat': {
            name: 'Miami Heat',
            description: 'The Miami Heat are an American professional basketball team based in Miami. The Heat compete in the National Basketball Association (NBA) as a member of the league\'s Eastern Conference Southeast Division.',
            stats: {
                'Championships': 3,
                'Conference Titles': 6,
                'Division Titles': 15,
                'Win Percentage': '.534'
            }
        },
        'bucks': {
            name: 'Milwaukee Bucks',
            description: 'The Milwaukee Bucks are an American professional basketball team based in Milwaukee. The Bucks compete in the National Basketball Association (NBA) as a member of the league\'s Eastern Conference Central Division.',
            stats: {
                'Championships': 2,
                'Conference Titles': 3,
                'Division Titles': 17,
                'Win Percentage': '.516'
            }
        }
    };
    
    // Return data for the requested team, or a default if not found
    return teamDataMap[teamId] || {
        name: teamId.charAt(0).toUpperCase() + teamId.slice(1),
        description: 'Team information not available.',
        stats: {
            'Championships': '-',
            'Conference Titles': '-',
            'Division Titles': '-',
            'Win Percentage': '-'
        }
    };
}

function fixNavigationLinks() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    console.log(`Found ${navLinks.length} navigation links`);
    
    navLinks.forEach(link => {
        // Clear existing events
        link.outerHTML = link.outerHTML;
        
        // Re-select after replacing
        const updatedLink = document.querySelector(`a[href="${link.getAttribute('href')}"]`);
        
        if (updatedLink) {
            updatedLink.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetSection = document.querySelector(targetId);
                if (targetSection) {
                    console.log("Scrolling to:", targetId);
                    
                    // Scroll to section
                    window.scrollTo({
                        top: targetSection.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Update active class
                    document.querySelectorAll('a[href^="#"]').forEach(l => 
                        l.classList.remove('active'));
                    this.classList.add('active');
                }
                
                return false;
            });
        }
    });
}

function fixBookButtons() {
    const bookButtons = document.querySelectorAll('.book-ticket');
    console.log(`Found ${bookButtons.length} book ticket buttons`);
    
    bookButtons.forEach(btn => {
        // Clear existing events
        btn.outerHTML = btn.outerHTML;
        
        // Re-select after replacing
        const updatedBtn = document.querySelector(`.book-ticket[data-game="${btn.getAttribute('data-game')}"]`);
        
        if (updatedBtn) {
            updatedBtn.style.position = 'relative';
            updatedBtn.style.zIndex = '2';
            updatedBtn.style.pointerEvents = 'auto';
            
            updatedBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const gameId = this.getAttribute('data-game');
                alert(`Booking tickets for game: ${gameId || 'unknown'}`);
                return false;
            });
        }
    });
}
