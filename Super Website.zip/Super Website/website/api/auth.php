<?php
// Include database connection
$conn = require_once '../db_connect.php';

// Set headers for JSON response
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle different request methods
switch ($method) {
    case 'POST':
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Check if action is set
        if (!isset($data['action'])) {
            echo json_encode(['success' => false, 'error' => 'Action not specified']);
            exit;
        }
        
        // Handle different actions
        switch ($data['action']) {
            case 'register':
                // Validate input
                if (!isset($data['username']) || !isset($data['password']) || !isset($data['email'])) {
                    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
                    exit;
                }
                
                // Sanitize input
                $username = $conn->real_escape_string($data['username']);
                $email = $conn->real_escape_string($data['email']);
                
                // Hash password
                $password = password_hash($data['password'], PASSWORD_DEFAULT);
                
                // Check if username already exists
                $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    echo json_encode(['success' => false, 'error' => 'Username already exists']);
                    exit;
                }
                
                // Check if email already exists
                $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    echo json_encode(['success' => false, 'error' => 'Email already exists']);
                    exit;
                }
                
                // Insert new user
                $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $username, $password, $email);
                
                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'userId' => $conn->insert_id]);
                } else {
                    echo json_encode(['success' => false, 'error' => $stmt->error]);
                }
                break;
                
            case 'login':
                // Validate input
                if (!isset($data['username']) || !isset($data['password'])) {
                    echo json_encode(['success' => false, 'error' => 'Missing username or password']);
                    exit;
                }
                
                // Sanitize input
                $username = $conn->real_escape_string($data['username']);
                
                // Get user from database
                $stmt = $conn->prepare("SELECT id, username, password, email FROM users WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    echo json_encode(['success' => false, 'error' => 'Invalid username or password']);
                    exit;
                }
                
                $user = $result->fetch_assoc();
                
                // Verify password
                if (password_verify($data['password'], $user['password'])) {
                    // Remove password from response
                    unset($user['password']);
                    
                    echo json_encode(['success' => true, 'user' => $user]);
                } else {
                    echo json_encode(['success' => false, 'error' => 'Invalid username or password']);
                }
                break;
                
            default:
                echo json_encode(['success' => false, 'error' => 'Invalid action']);
                break;
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        break;
}

// Close connection
$conn->close();
?>
