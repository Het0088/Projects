<?php
// Include database connection
$conn = require_once '../db_connect.php';

// Set headers for JSON response
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle different request methods
switch ($method) {
    case 'GET':
        // Get games with available tickets
        $sql = "SELECT id, home_team, away_team, game_date, game_time, venue, tickets_available 
                FROM games 
                WHERE tickets_available > 0 
                AND game_date >= CURDATE() 
                ORDER BY game_date ASC";
        
        $result = $conn->query($sql);
        
        if (!$result) {
            echo json_encode(['success' => false, 'error' => $conn->error]);
            exit;
        }
        
        $games = [];
        while ($row = $result->fetch_assoc()) {
            $games[] = $row;
        }
        
        echo json_encode(['success' => true, 'games' => $games]);
        break;
        
    case 'POST':
        // Book tickets for a game
        
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate input
        if (!isset($data['game_id']) || !isset($data['user_id']) || !isset($data['ticket_type']) || 
            !isset($data['quantity']) || !isset($data['section']) || !isset($data['total_price'])) {
            echo json_encode(['success' => false, 'error' => 'Missing required fields']);
            exit;
        }
        
        // Sanitize input
        $gameId = (int)$data['game_id'];
        $userId = (int)$data['user_id'];
        $ticketType = $conn->real_escape_string($data['ticket_type']);
        $quantity = (int)$data['quantity'];
        $section = $conn->real_escape_string($data['section']);
        $totalPrice = (float)$data['total_price'];
        
        // Check if game exists and has enough tickets
        $stmt = $conn->prepare("SELECT tickets_available FROM games WHERE id = ?");
        $stmt->bind_param("i", $gameId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            echo json_encode(['success' => false, 'error' => 'Game not found']);
            exit;
        }
        
        $game = $result->fetch_assoc();
        
        if ($game['tickets_available'] < $quantity) {
            echo json_encode(['success' => false, 'error' => 'Not enough tickets available']);
            exit;
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert ticket booking
            $stmt = $conn->prepare("INSERT INTO tickets (game_id, user_id, ticket_type, quantity, section, total_price) 
                                    VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iisiss", $gameId, $userId, $ticketType, $quantity, $section, $totalPrice);
            $stmt->execute();
            
            // Update available tickets
            $stmt = $conn->prepare("UPDATE games SET tickets_available = tickets_available - ? WHERE id = ?");
            $stmt->bind_param("ii", $quantity, $gameId);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode(['success' => true, 'ticketId' => $conn->insert_id]);
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        break;
}

// Close connection
$conn->close();
?>
