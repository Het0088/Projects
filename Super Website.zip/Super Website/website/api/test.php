<?php
// Simple test file to check if PHP is available
header('Content-Type: application/json');
echo json_encode(['php_available' => true]);
?>
