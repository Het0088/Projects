<?php
// Include database connection
$conn = require_once '../db_connect.php';

// Set headers for JSON response
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle different request methods
switch ($method) {
    case 'GET':
        // Get available courts or bookings
        if (isset($_GET['user_id'])) {
            // Get bookings for a specific user
            $userId = (int)$_GET['user_id'];
            
            $sql = "SELECT cb.*, 
                    CASE 
                        WHEN cb.court_id = 'downtown' THEN 'Downtown Basketball Court'
                        WHEN cb.court_id = 'riverside' THEN 'Riverside Park Court'
                        WHEN cb.court_id = 'community' THEN 'Community Center Court'
                        ELSE cb.court_id
                    END as court_name
                    FROM court_bookings cb
                    WHERE cb.user_id = $userId
                    ORDER BY cb.booking_date ASC, cb.booking_time ASC";
            
            $result = $conn->query($sql);
            
            if (!$result) {
                echo json_encode(['success' => false, 'error' => $conn->error]);
                exit;
            }
            
            $bookings = [];
            while ($row = $result->fetch_assoc()) {
                $bookings[] = $row;
            }
            
            echo json_encode(['success' => true, 'bookings' => $bookings]);
        } else {
            // Return list of courts
            $courts = [
                [
                    'id' => 'downtown',
                    'name' => 'Downtown Basketball Court',
                    'address' => '123 Main St, City Center',
                    'hours' => '6 AM - 10 PM',
                    'image' => 'https://images.unsplash.com/photo-1505666287802-931dc83a0fe4?w=800&q=80',
                    'lat' => 40.7128,
                    'lng' => -74.0060
                ],
                [
                    'id' => 'riverside',
                    'name' => 'Riverside Park Court',
                    'address' => '456 River Rd, Riverside',
                    'hours' => '7 AM - 9 PM',
                    'image' => 'https://images.unsplash.com/photo-1505250469679-203ad9ced0cb?w=800&q=80',
                    'lat' => 40.7831,
                    'lng' => -73.9712
                ],
                [
                    'id' => 'community',
                    'name' => 'Community Center Court',
                    'address' => '789 Community Ave',
                    'hours' => '8 AM - 8 PM',
                    'image' => 'https://images.unsplash.com/photo-1613371510307-bdcbf59cd3a3?w=800&q=80',
                    'lat' => 40.7282,
                    'lng' => -73.7949
                ]
            ];
            
            echo json_encode(['success' => true, 'courts' => $courts]);
        }
        break;
        
    case 'POST':
        // Book a court
        
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate input
        if (!isset($data['court_id']) || !isset($data['user_id']) || !isset($data['booking_date']) || 
            !isset($data['booking_time']) || !isset($data['num_players'])) {
            echo json_encode(['success' => false, 'error' => 'Missing required fields']);
            exit;
        }
        
        // Sanitize input
        $courtId = $conn->real_escape_string($data['court_id']);
        $userId = (int)$data['user_id'];
        $bookingDate = $conn->real_escape_string($data['booking_date']);
        $bookingTime = $conn->real_escape_string($data['booking_time']);
        $numPlayers = (int)$data['num_players'];
        $notes = isset($data['notes']) ? $conn->real_escape_string($data['notes']) : '';
        
        // Check if the court is already booked at that time
        $stmt = $conn->prepare("SELECT id FROM court_bookings 
                               WHERE court_id = ? AND booking_date = ? AND booking_time = ?");
        $stmt->bind_param("sss", $courtId, $bookingDate, $bookingTime);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo json_encode(['success' => false, 'error' => 'Court already booked at this time']);
            exit;
        }
        
        // Insert booking
        $stmt = $conn->prepare("INSERT INTO court_bookings (court_id, user_id, booking_date, booking_time, num_players, notes) 
                               VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sissss", $courtId, $userId, $bookingDate, $bookingTime, $numPlayers, $notes);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'bookingId' => $conn->insert_id]);
        } else {
            echo json_encode(['success' => false, 'error' => $stmt->error]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        break;
}

// Close connection
$conn->close();
?>
