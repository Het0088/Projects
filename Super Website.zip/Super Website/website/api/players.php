<?php
// Include database connection
$conn = require_once '../db_connect.php';

// Set headers for JSON response
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Handle different request methods
switch ($method) {
    case 'GET':
        // Check if we're getting a specific player or all players
        if (isset($_GET['id'])) {
            // Get specific player
            $id = $conn->real_escape_string($_GET['id']);
            $sql = "SELECT * FROM players WHERE id = $id";
        } else {
            // Get all players with optional search and pagination
            $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
            $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
            
            $sql = "SELECT * FROM players";
            
            if (!empty($search)) {
                $sql .= " WHERE name LIKE '%$search%' OR team LIKE '%$search%' OR position LIKE '%$search%'";
            }
            
            $sql .= " ORDER BY name ASC LIMIT $limit OFFSET $offset";
        }
        
        $result = $conn->query($sql);
        
        if (!$result) {
            echo json_encode(['success' => false, 'error' => $conn->error]);
            exit;
        }
        
        $players = [];
        while ($row = $result->fetch_assoc()) {
            $players[] = $row;
        }
        
        echo json_encode(['success' => true, 'players' => $players]);
        break;
        
    case 'POST':
        // Check if user is authenticated (would use sessions in a real app)
        
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate input
        if (!isset($data['name']) || !isset($data['team']) || !isset($data['position'])) {
            echo json_encode(['success' => false, 'error' => 'Missing required fields']);
            exit;
        }
        
        // Sanitize input
        $name = $conn->real_escape_string($data['name']);
        $team = $conn->real_escape_string($data['team']);
        $position = $conn->real_escape_string($data['position']);
        $points = isset($data['points_per_game']) ? (float)$data['points_per_game'] : 0;
        $rebounds = isset($data['rebounds_per_game']) ? (float)$data['rebounds_per_game'] : 0;
        $assists = isset($data['assists_per_game']) ? (float)$data['assists_per_game'] : 0;
        $image = isset($data['image_url']) ? $conn->real_escape_string($data['image_url']) : '';
        
        // Insert new player
        $sql = "INSERT INTO players (name, team, position, points_per_game, rebounds_per_game, assists_per_game, image_url) 
                VALUES ('$name', '$team', '$position', $points, $rebounds, $assists, '$image')";
        
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'playerId' => $conn->insert_id]);
        } else {
            echo json_encode(['success' => false, 'error' => $conn->error]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        break;
}

// Close connection
$conn->close();
?>
