// Basketball Courts Map and Booking System

// Global variables
let map;
let markers = [];
let courts = [];
let selectedCourt = null;
let userMarker = null;
let userLocation; // Declare userLocation only once

async function loadCourts() {
    try {
        const response = await fetch('api/courts.php');
        const data = await response.json();
        
        if (data.success) {
            courts = data.courts;
            renderCourtsList();
            
            // If Google Maps is loaded, add markers
            if (typeof google !== 'undefined' && google.maps && map) {
                addCourtMarkers();
            }
        } else {
            console.error('Error loading courts:', data.error);
        }
    } catch (error) {
        console.error('Error loading courts:', error);
        // Fallback to sample data
        courts = [
            {
                id: 'downtown',
                name: 'Downtown Basketball Court',
                address: '123 Main St, City Center',
                hours: '6 AM - 10 PM',
                image: 'https://images.unsplash.com/photo-1505666287802-931dc83a0fe4?w=800&q=80',
                lat: 40.7128,
                lng: -74.0060
            },
            {
                id: 'riverside',
                name: 'Riverside Park Court',
                address: '456 River Rd, Riverside',
                hours: '7 AM - 9 PM',
                image: 'https://images.unsplash.com/photo-1505250469679-203ad9ced0cb?w=800&q=80',
                lat: 40.7831,
                lng: -73.9712
            },
            {
                id: 'community',
                name: 'Community Center Court',
                address: '789 Community Ave',
                hours: '8 AM - 8 PM',
                image: 'https://images.unsplash.com/photo-1613371510307-bdcbf59cd3a3?w=800&q=80',
                lat: 40.7282,
                lng: -73.7949
            }
        ];
        renderCourtsList();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initializeCourtMap();
    loadCourts();
    
    // Initialize court booking modal
    initializeCourtBookingModal();
    
    // Add event listener for find courts button
    const findCourtsBtn = document.getElementById('findCourts');
    if (findCourtsBtn) {
        findCourtsBtn.addEventListener('click', findCourtsNearLocation);
    }
    
    // Add event listener for use current location button
    const useCurrentLocationBtn = document.getElementById('useCurrentLocation');
    if (useCurrentLocationBtn) {
        useCurrentLocationBtn.addEventListener('click', useCurrentLocation);
    }
    
    // Initialize court booking modal
    initializeCourtBookingModal();
});

// Load Google Maps API script
function loadGoogleMapsAPI() {
    if (document.getElementById('google-maps-api')) {
        return; // Already loaded
    }
    
    const script = document.createElement('script');
    script.id = 'google-maps-api';
    script.src = 'https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places&callback=initMap';
    script.async = true;
    script.defer = true;
    document.head.appendChild(script);
    
    // Add a note about API key
    const mapContainer = document.getElementById('courtsMap');
    if (mapContainer) {
        mapContainer.innerHTML = `
            <div class="map-placeholder">
                <p>Please replace 'YOUR_API_KEY' in courts-map.js with a valid Google Maps API key.</p>
                <p>Until then, we'll show you a list of courts below.</p>
            </div>
        `;
    }
}

function openCourtBookingModal(courtId) {
    const court = courts.find(c => c.id === courtId);
    if (!court) return;
    
    selectedCourt = court;
    
    const modal = document.getElementById('courtBookingModal');
    const courtDetails = document.getElementById('courtBookingDetails');
    
    if (modal && courtDetails) {
        courtDetails.innerHTML = `
            <div class="court-booking-header">
                <img src="${court.image}" alt="${court.name}" class="court-booking-image">
                <div class="court-booking-info">
                    <h3>${court.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${court.address}</p>
                    <p><i class="far fa-clock"></i> ${court.hours}</p>
                </div>
            </div>
        `;
        
        modal.style.display = 'flex';
    }
}
    
    map = new google.maps.Map(mapContainer, {
        center: defaultCenter,
        zoom: 12,
        styles: [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            {
                featureType: "administrative.locality",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "poi",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "poi.park",
                elementType: "geometry",
                stylers: [{ color: "#263c3f" }],
            },
            {
                featureType: "poi.park",
                elementType: "labels.text.fill",
                stylers: [{ color: "#6b9a76" }],
            },
            {
                featureType: "road",
                elementType: "geometry",
                stylers: [{ color: "#38414e" }],
            },
            {
                featureType: "road",
                elementType: "geometry.stroke",
                stylers: [{ color: "#212a37" }],
            },
            {
                featureType: "road",
                elementType: "labels.text.fill",
                stylers: [{ color: "#9ca5b3" }],
            },
            {
                featureType: "road.highway",
                elementType: "geometry",
                stylers: [{ color: "#746855" }],
            },
            {
                featureType: "road.highway",
                elementType: "geometry.stroke",
                stylers: [{ color: "#1f2835" }],
            },
            {
                featureType: "road.highway",
                elementType: "labels.text.fill",
                stylers: [{ color: "#f3d19c" }],
            },
            {
                featureType: "transit",
                elementType: "geometry",
                stylers: [{ color: "#2f3948" }],
            },
            {
                featureType: "transit.station",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "water",
                elementType: "geometry",
                stylers: [{ color: "#17263c" }],
            },
            {
                featureType: "water",
                elementType: "labels.text.fill",
                stylers: [{ color: "#515c6d" }],
            },
            {
                featureType: "water",
                elementType: "labels.text.stroke",
                stylers: [{ color: "#17263c" }],
            },
        ],
    });
    
    // Initialize Places Autocomplete for location input
    const locationInput = document.getElementById('locationInput');
    if (locationInput) {
        const autocomplete = new google.maps.places.Autocomplete(locationInput);
        autocomplete.bindTo('bounds', map);
        
        autocomplete.addListener('place_changed', () => {
            const place = autocomplete.getPlace();
            
            if (!place.geometry || !place.geometry.location) {
                console.log("No details available for input: '" + place.name + "'");
                return;
            }
            
            // Set the user's location
            userLocation = {
                lat: place.geometry.location.lat(),
                lng: place.geometry.location.lng()
            };
            
            // Update map
            map.setCenter(userLocation);
            map.setZoom(14);
            
            // Update user marker
            updateUserMarker(userLocation);
            
            // Find courts near this location
            findNearestCourts(userLocation);
        });
    }
    
    // Try to get user's location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };
                map.setCenter(userLocation);
                
                // Add a marker for user's location
                updateUserMarker(userLocation);
                
                // Add court markers
                addCourtMarkers();
                
                // Find courts near user
                findNearestCourts(userLocation);
            },
            () => {
                // Handle location error
                console.log("Error: The Geolocation service failed.");
                // Still add court markers with default center
                addCourtMarkers();
            }
        );
    } else {
        // Browser doesn't support Geolocation
        console.log("Error: Your browser doesn't support geolocation.");
        // Still add court markers with default center
        addCourtMarkers();
    }


function initializeCourtBookingModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('courtBookingModal')) {
        const modalHTML = `
            <div id="courtBookingModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    
                    <h2>Book Basketball Court</h2>
                    <div id="courtBookingDetails"></div>
                    
                    <form id="courtBookingForm">
                        <div class="form-group">
                            <label for="bookingDate">Date</label>
                            <input type="date" id="bookingDate" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="bookingTime">Time</label>
                            <select id="bookingTime" required>
                                <option value="">Select a time</option>
                                <option value="08:00:00">8:00 AM</option>
                                <option value="09:00:00">9:00 AM</option>
                                <option value="10:00:00">10:00 AM</option>
                                <option value="11:00:00">11:00 AM</option>
                                <option value="12:00:00">12:00 PM</option>
                                <option value="13:00:00">1:00 PM</option>
                                <option value="14:00:00">2:00 PM</option>
                                <option value="15:00:00">3:00 PM</option>
                                <option value="16:00:00">4:00 PM</option>
                                <option value="17:00:00">5:00 PM</option>
                                <option value="18:00:00">6:00 PM</option>
                                <option value="19:00:00">7:00 PM</option>
                                <option value="20:00:00">8:00 PM</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="numPlayers">Number of Players</label>
                            <input type="number" id="numPlayers" min="1" max="20" value="2" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="bookingNotes">Notes (Optional)</label>
                            <textarea id="bookingNotes" rows="3"></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" id="cancelBookingBtn" class="btn-secondary">Cancel</button>
                            <button type="submit" id="confirmBookingBtn" class="btn-primary">Book Court</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Add event listeners
        const modal = document.getElementById('courtBookingModal');
        const closeBtn = modal.querySelector('.close-modal');
        const cancelBtn = document.getElementById('cancelBookingBtn');
        const bookingForm = document.getElementById('courtBookingForm');
        
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        cancelBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        bookingForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Check if user is logged in
            if (!currentUser) {
                alert('Please log in to book a court.');
                modal.style.display = 'none';
                
                // Open auth modal if it exists
                const authModal = document.getElementById('authModal');
                if (authModal) {
                    authModal.style.display = 'flex';
                    const loginTab = document.getElementById('loginTab');
                    if (loginTab) loginTab.click();
                }
                return;
            }
            
            // Get form values
            const date = document.getElementById('bookingDate').value;
            const time = document.getElementById('bookingTime').value;
            const numPlayers = document.getElementById('numPlayers').value;
            const notes = document.getElementById('bookingNotes').value;
            
            // Show loading state
            const submitBtn = document.getElementById('confirmBookingBtn');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Booking...';
            submitBtn.disabled = true;
            
            try {
                const response = await fetch('api/courts.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        court_id: selectedCourt.id,
                        user_id: currentUser.id,
                        booking_date: date,
                        booking_time: time,
                        num_players: numPlayers,
                        notes: notes
                    })
                });
                
                const data = await response.json();
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                if (data.success) {
                    alert(`Court booked successfully! Your booking ID is ${data.bookingId}.`);
                    modal.style.display = 'none';
                } else {
                    alert(`Booking failed: ${data.error}`);
                }
            } catch (error) {
                console.error('Error booking court:', error);
                alert('An error occurred while booking the court. Please try again.');
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });
        
        // Set min date to today
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const formattedDate = `${yyyy}-${mm}-${dd}`;
        
        document.getElementById('bookingDate').min = formattedDate;
        document.getElementById('bookingDate').value = formattedDate;
    }
}

// Find courts near a location
function findNearestCourts(location) {
    if (!location || courts.length === 0) return;
    
    // Calculate distance from location to each court
    courts.forEach(court => {
        court.distance = calculateDistance(
            location.lat, location.lng,
            court.lat, court.lng
        );
    });
    
    // Sort courts by distance
    courts.sort((a, b) => a.distance - b.distance);
    
    // Update markers and list
    addCourtMarkers();
    renderCourtsList();
}

// Calculate distance between two points using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const d = R * c; // Distance in km
    return d;
}

function deg2rad(deg) {
    return deg * (Math.PI/180);
}

// Find courts near the entered location
function findCourtsNearLocation() {
    const locationInput = document.getElementById('locationInput');
    if (!locationInput || !locationInput.value.trim()) {
        alert('Please enter a location to search for courts');
        return;
    }
    
    // If we don't have the Places API, use a geocoding service
    if (!google.maps.places) {
        // Use a geocoding service to convert address to coordinates
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: locationInput.value }, (results, status) => {
            if (status === 'OK' && results[0]) {
                const location = {
                    lat: results[0].geometry.location.lat(),
                    lng: results[0].geometry.location.lng()
                };
                
                // Update map and user marker
                map.setCenter(location);
                map.setZoom(14);
                updateUserMarker(location);
                
                // Find courts near this location
                findNearestCourts(location);
            } else {
                alert('Could not find that location. Please try again.');
            }
        });
    }
}

// Add markers for all courts
function addCourtMarkers() {
    if (!map || courts.length === 0) return;
    
    // Clear existing markers
    markers.forEach(marker => marker.setMap(null));
    markers = [];
    
    // Add new markers
    courts.forEach(court => {
        const marker = new google.maps.Marker({
            position: { lat: court.lat, lng: court.lng },
            map: map,
            title: court.name,
            icon: {
                url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
            },
            animation: google.maps.Animation.DROP,
        });
        
        // Add click event
        marker.addListener('click', () => {
            // Open info window
            const infoWindow = new google.maps.InfoWindow({
                content: `
                    <div class="map-info-window">
                        <h3>${court.name}</h3>
                        <p>${court.address}</p>
                        <p>Hours: ${court.hours}</p>
                        <button id="viewCourtBtn" onclick="viewCourtDetails('${court.id}')">View Details</button>
                    </div>
                `,
            });
            
            infoWindow.open(map, marker);
        });
        
        markers.push(marker);
    });
}

// Initialize the court map section
function initializeCourtMap() {
    const courtsSection = document.getElementById('courtsSection');
    let userLocation = null; // Initialize userLocation variable
    if (!courtsSection) {
        // Create courts section if it doesn't exist
        const section = document.createElement('section');
        section.id = 'courtsSection';
        section.className = 'section courts-section';
        section.innerHTML = `
            <div class="section-header">
                <h2>Basketball Courts Near You</h2>
                <p>Find and book basketball courts in your area</p>
            </div>
            
            <div class="courts-container">
                <div id="courtsMap" class="courts-map"></div>
                
                <div id="courtsList" class="courts-list">
                    <div class="courts-list-loading">
                        <div class="spinner"></div>
                        <p>Loading courts...</p>
                    </div>
                </div>
            </div>
        `;
        
        // Find where to insert the section (before the footer)
        const footer = document.querySelector('footer');
        if (footer) {
            document.body.insertBefore(section, footer);
        } else {
            document.body.appendChild(section);
        }
        
        // Add styles for courts section
        if (!document.getElementById('courtsStyles')) {
            const courtsStyles = `
                .courts-section {
                    padding: 4rem 2rem;
                    background: var(--dark-bg, #0f0f1e);
                }
                
                .courts-container {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 2rem;
                    margin-top: 2rem;
                }
                
                .courts-map {
                    flex: 1;
                    min-height: 400px;
                    border-radius: 15px;
                    overflow: hidden;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
                }
                
                .map-placeholder {
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    background: var(--card-bg, #1a1a2e);
                    color: var(--text-dim, #ccc);
                    text-align: center;
                    padding: 2rem;
                }
                
                .courts-list {
                    flex: 1;
                    min-width: 300px;
                    max-height: 600px;
                    overflow-y: auto;
                    padding-right: 1rem;
                }
                
                .courts-list-loading {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    height: 200px;
                }
                
                .spinner {
                    width: 40px;
                    height: 40px;
                    border: 4px solid rgba(255, 255, 255, 0.1);
                    border-radius: 50%;
                    border-top-color: var(--accent-color, #f72585);
                    animation: spin 1s ease-in-out infinite;
                    margin-bottom: 1rem;
                }
                
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
                
                .court-card {
                    background: var(--card-bg, #1a1a2e);
                    border-radius: 15px;
                    overflow: hidden;
                    margin-bottom: 1.5rem;
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }
                
                .court-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
                }
                
                .court-image {
                    width: 100%;
                    height: 180px;
                    object-fit: cover;
                }
                
                .court-details {
                    padding: 1.5rem;
                }
                
                .court-details h3 {
                    font-size: 1.3rem;
                    margin-bottom: 0.5rem;
                    color: var(--text-light, #fff);
                }
                
                .court-details p {
                    color: var(--text-dim, #ccc);
                    margin-bottom: 0.5rem;
                }
                
                .court-actions {
                    display: flex;
                    justify-content: space-between;
                    margin-top: 1rem;
                }
                
                .btn-book-court {
                    background: var(--primary-color, #4361ee);
                    color: white;
                    border: none;
                    padding: 0.6rem 1.2rem;
                    border-radius: 8px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .btn-book-court:hover {
                    background: var(--accent-color, #f72585);
                    transform: translateY(-2px);
                }
                
                .btn-view-map {
                    background: transparent;
                    color: var(--text-dim, #ccc);
                    border: 1px solid var(--card-border, #2a2a4a);
                    padding: 0.6rem 1.2rem;
                    border-radius: 8px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .btn-view-map:hover {
                    color: var(--text-light, #fff);
                    border-color: var(--text-light, #fff);
                }
                
                .map-info-window {
                    padding: 0.5rem;
                    max-width: 250px;
                }
                
                .map-info-window h3 {
                    font-size: 1.1rem;
                    margin-bottom: 0.5rem;
                }
                
                .map-info-window p {
                    margin-bottom: 0.5rem;
                    font-size: 0.9rem;
                }
                
                .map-info-window button {
                    background: var(--primary-color, #4361ee);
                    color: white;
                    border: none;
                    padding: 0.4rem 0.8rem;
                    border-radius: 4px;
                    font-size: 0.9rem;
                    cursor: pointer;
                    margin-top: 0.5rem;
                }
                
                @media (max-width: 768px) {
                    .courts-container {
                        flex-direction: column;
                    }
                    
                    .courts-map {
                        min-height: 300px;
                    }
                }
            `;
            
            const styleElement = document.createElement('style');
            styleElement.id = 'courtsStyles';
            styleElement.textContent = courtsStyles;
            document.head.appendChild(styleElement);
        }
    }
    
    // Load Google Maps API
    loadGoogleMapsAPI();
}

// Load courts from API
async function loadCourts() {
    try {
        const response = await fetch('api/courts.php');
        const data = await response.json();
        
        if (data.success) {
            courts = data.courts;
            renderCourtsList();
            
            // If Google Maps is loaded, add markers
            if (typeof google !== 'undefined' && google.maps && map) {
                addCourtMarkers();
            }
        } else {
            console.error('Error loading courts:', data.error);
        }
    } catch (error) {
        console.error('Error loading courts:', error);
        // Fallback to sample data
        courts = [
            {
                id: 'downtown',
                name: 'Downtown Basketball Court',
                address: '123 Main St, City Center',
                hours: '6 AM - 10 PM',
                image: 'https://images.unsplash.com/photo-1505666287802-931dc83a0fe4?w=800&q=80',
                lat: 40.7128,
                lng: -74.0060
            },
            {
                id: 'riverside',
                name: 'Riverside Park Court',
                address: '456 River Rd, Riverside',
                hours: '7 AM - 9 PM',
                image: 'https://images.unsplash.com/photo-1505250469679-203ad9ced0cb?w=800&q=80',
                lat: 40.7831,
                lng: -73.9712
            },
            {
                id: 'community',
                name: 'Community Center Court',
                address: '789 Community Ave',
                hours: '8 AM - 8 PM',
                image: 'https://images.unsplash.com/photo-1613371510307-bdcbf59cd3a3?w=800&q=80',
                lat: 40.7282,
                lng: -73.7949
            }
        ];
        renderCourtsList();
    }
}

// Render the list of courts
function renderCourtsList() {
    const courtsList = document.getElementById('courtsList');
    if (!courtsList) return;
    
    if (courts.length === 0) {
        courtsList.innerHTML = '<p>No courts found in your area.</p>';
        return;
    }
    
    let html = '';
    courts.forEach(court => {
        html += `
            <div class="court-card" data-court-id="${court.id}">
                <img src="${court.image}" alt="${court.name}" class="court-image">
                <div class="court-details">
                    <h3>${court.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${court.address}</p>
                    <p><i class="far fa-clock"></i> ${court.hours}</p>
                    <div class="court-actions">
                        <button class="btn-book-court" onclick="openCourtBookingModal('${court.id}')">Book Court</button>
                        <button class="btn-view-map" onclick="viewOnMap('${court.id}')">View on Map</button>
                    </div>
                </div>
            </div>
        `;
    });
    
    courtsList.innerHTML = html;
}

// View court on map
function viewOnMap(courtId) {
    const court = courts.find(c => c.id === courtId);
    if (!court || !map) return;
    
    map.setCenter({ lat: court.lat, lng: court.lng });
    map.setZoom(16);
    
    // Find and animate the marker
    const marker = markers.find(m => m.getTitle() === court.name);
    if (marker) {
        marker.setAnimation(google.maps.Animation.BOUNCE);
        setTimeout(() => {
            marker.setAnimation(null);
        }, 2100);
        
        // Trigger click to show info window
        google.maps.event.trigger(marker, 'click');
    }
}

// View court details
function viewCourtDetails(courtId) {
    const court = courts.find(c => c.id === courtId);
    if (!court) return;
    
    // Find the court card and scroll to it
    const courtCard = document.querySelector(`.court-card[data-court-id="${courtId}"]`);
    if (courtCard) {
        courtCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Highlight the card
        courtCard.style.boxShadow = '0 0 0 3px var(--accent-color, #f72585)';
        setTimeout(() => {
            courtCard.style.boxShadow = '';
        }, 2000);
    }
}

// Initialize court booking modal
function initializeCourtBookingModal() {
    // Create modal if it doesn't exist
    if (!document.getElementById('courtBookingModal')) {
        const modalHTML = `
            <div id="courtBookingModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal">&times;</span>
                    
                    <h2>Book Basketball Court</h2>
                    <div id="courtBookingDetails"></div>
                    
                    <form id="courtBookingForm">
                        <div class="form-group">
                            <label for="bookingDate">Date</label>
                            <input type="date" id="bookingDate" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="bookingTime">Time</label>
                            <select id="bookingTime" required>
                                <option value="">Select a time</option>
                                <option value="08:00:00">8:00 AM</option>
                                <option value="09:00:00">9:00 AM</option>
                                <option value="10:00:00">10:00 AM</option>
                                <option value="11:00:00">11:00 AM</option>
                                <option value="12:00:00">12:00 PM</option>
                                <option value="13:00:00">1:00 PM</option>
                                <option value="14:00:00">2:00 PM</option>
                                <option value="15:00:00">3:00 PM</option>
                                <option value="16:00:00">4:00 PM</option>
                                <option value="17:00:00">5:00 PM</option>
                                <option value="18:00:00">6:00 PM</option>
                                <option value="19:00:00">7:00 PM</option>
                                <option value="20:00:00">8:00 PM</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="numPlayers">Number of Players</label>
                            <input type="number" id="numPlayers" min="1" max="20" value="2" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="bookingNotes">Notes (Optional)</label>
                            <textarea id="bookingNotes" rows="3"></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" id="cancelBookingBtn" class="btn-secondary">Cancel</button>
                            <button type="submit" id="confirmBookingBtn" class="btn-primary">Book Court</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Add event listeners
        const modal = document.getElementById('courtBookingModal');
        const closeBtn = modal.querySelector('.close-modal');
        const cancelBtn = document.getElementById('cancelBookingBtn');
        const bookingForm = document.getElementById('courtBookingForm');
        
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        cancelBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        bookingForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Check if user is logged in
            if (!currentUser) {
                alert('Please log in to book a court.');
                modal.style.display = 'none';
                
                // Open auth modal if it exists
                const authModal = document.getElementById('authModal');
                if (authModal) {
                    authModal.style.display = 'flex';
                    const loginTab = document.getElementById('loginTab');
                    if (loginTab) loginTab.click();
                }
                return;
            }
            
            // Get form values
            const date = document.getElementById('bookingDate').value;
            const time = document.getElementById('bookingTime').value;
            const numPlayers = document.getElementById('numPlayers').value;
            const notes = document.getElementById('bookingNotes').value;
            
            // Show loading state
            const submitBtn = document.getElementById('confirmBookingBtn');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Booking...';
            submitBtn.disabled = true;
            
            try {
                const response = await fetch('api/courts.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        court_id: selectedCourt.id,
                        user_id: currentUser.id,
                        booking_date: date,
                        booking_time: time,
                        num_players: numPlayers,
                        notes: notes
                    })
                });
                
                const data = await response.json();
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                if (data.success) {
                    alert(`Court booked successfully! Your booking ID is ${data.bookingId}.`);
                    modal.style.display = 'none';
                } else {
                    alert(`Booking failed: ${data.error}`);
                }
            } catch (error) {
                console.error('Error booking court:', error);
                alert('An error occurred while booking the court. Please try again.');
                
                // Reset button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }
        });
        
        // Set min date to today
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const formattedDate = `${yyyy}-${mm}-${dd}`;
        
        document.getElementById('bookingDate').min = formattedDate;
        document.getElementById('bookingDate').value = formattedDate;
    }
}

// Open court booking modal
function openCourtBookingModal(courtId) {
    const court = courts.find(c => c.id === courtId);
    if (!court) return;
    
    selectedCourt = court;
    
    const modal = document.getElementById('courtBookingModal');
    const courtDetails = document.getElementById('courtBookingDetails');
    
    if (modal && courtDetails) {
        courtDetails.innerHTML = `
            <div class="court-booking-header">
                <img src="${court.image}" alt="${court.name}" class="court-booking-image">
                <div class="court-booking-info">
                    <h3>${court.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${court.address}</p>
                    <p><i class="far fa-clock"></i> ${court.hours}</p>
                </div>
            </div>
        `;
        
        modal.style.display = 'flex';
    }
}

// Use current location
function useCurrentLocation() {
    if (navigator.geolocation) {
        // Show loading indicator
        const courtsList = document.getElementById('courtsList');
        if (courtsList) {
            courtsList.innerHTML = `
                <div class="court-loading">
                    <div class="spinner"></div>
                    <p>Getting your location...</p>
                </div>
            `;
        }
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                userLocation = { 
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };

                
                // Update the location input with coordinates
                const locationInput = document.getElementById('locationInput');
                if (locationInput) {
                    locationInput.value = `${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}`;
                }
                
                // Update map
                if (map) {
                    map.setCenter(userLocation);
                    map.setZoom(14);
                    updateUserMarker(userLocation);
                }
                
                // Find courts near user
                findNearestCourts(userLocation);
            }
            (error) => {
                // Handle location error
                // Handle location error
                // Handle location error
                // Handle location error
                // Handle location error
                // Handle location error
                console.error("Error getting location:", error);
                
                let errorMessage = "Could not get your location.";
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage = "Location access was denied. Please enable location services in your browser settings.";
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage = "Location information is unavailable.";
                        break;
                    case error.TIMEOUT:
                        errorMessage = "The request to get your location timed out.";
                        break;
                    case error.UNKNOWN_ERROR:
                        errorMessage = "An unknown error occurred while getting your location.";
                        break;
                }
                
                alert(errorMessage);
                
                // Reset the courts list
                const courtsList = document.getElementById('courtsList');
                if (courtsList) {
                    courtsList.innerHTML = `
                        <div class="no-results">
                            <p>${errorMessage}</p>
                            <p>Please enter your location manually.</p>
                        </div>
                    `;
                }
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
    };
    else {
        // Browser doesn't support Geolocation
        alert("Your browser doesn't support geolocation. Please enter your location manually.");
    }
