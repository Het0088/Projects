// User authentication and profile management

// Global variables
let currentUser = null;

// Initialize user authentication when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeUserDropdown();
    initializeAuthModal();
    
    // Check if user is logged in from session storage
    const savedUser = sessionStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        updateUIForLoggedInUser();
    }
});

// User registration
async function registerUser(username, password, email) {
    try {
        const response = await fetch('api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'register',
                username: username,
                password: password,
                email: email
            })
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// User login
async function loginUser(username, password) {
    try {
        const response = await fetch('api/auth.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'login',
                username: username,
                password: password
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.user;
            // Save user to session storage
            sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // If loadUserFavorites exists (from players.js), call it
            if (typeof loadUserFavorites === 'function') {
                loadUserFavorites();
            }
        }
        
        return data;
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// Logout user
function logoutUser() {
    currentUser = null;
    // Clear user from session storage
    sessionStorage.removeItem('currentUser');
    
    // If userFavorites exists (from players.js), reset it
    if (typeof userFavorites !== 'undefined') {
        userFavorites = [];
    }
    
    updateUIForLoggedOutUser();
    return { success: true };
}

// Initialize user profile dropdown
function initializeUserDropdown() {
    const userProfileBtn = document.getElementById('userProfileBtn');
    const userDropdown = document.getElementById('userDropdown');
    
    if (userProfileBtn && userDropdown) {
        userProfileBtn.addEventListener('click', () => {
            userDropdown.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!userProfileBtn.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('active');
            }
        });
    }
}

// Initialize auth modal functionality
function initializeAuthModal() {
    // Get modal elements
    const authModal = document.getElementById('authModal');
    const loginTab = document.getElementById('loginTab');
    const registerTab = document.getElementById('registerTab');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const closeModal = document.querySelector('.close-modal');
    
    // If modal elements don't exist, create them
    if (!authModal) {
        createAuthModal();
        return; // After creating, we'll initialize on next load
    }
    
    // Open modal when login/register links are clicked
    document.querySelectorAll('a[href="#login"], a[href="#register"]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            authModal.style.display = 'flex';
            
            // Switch to appropriate tab
            if (e.target.getAttribute('href') === '#register' && registerTab) {
                registerTab.click();
            } else if (loginTab) {
                loginTab.click();
            }
        });
    });
    
    // Close modal when clicking the close button or outside the modal
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            authModal.style.display = 'none';
        });
    }
    
    window.addEventListener('click', (e) => {
        if (e.target === authModal) {
            authModal.style.display = 'none';
        }
    });
    
    // Tab switching functionality
    if (loginTab && registerTab) {
        loginTab.addEventListener('click', () => {
            loginTab.classList.add('active');
            registerTab.classList.remove('active');
            loginForm.classList.add('active');
            registerForm.classList.remove('active');
        });
        
        registerTab.addEventListener('click', () => {
            registerTab.classList.add('active');
            loginTab.classList.remove('active');
            registerForm.classList.add('active');
            loginForm.classList.remove('active');
        });
    }
    
    // Form submission handling
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('loginUsername').value;
            const password = document.getElementById('loginPassword').value;
            
            // Show loading state
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Logging in...';
            submitBtn.disabled = true;
            
            const result = await loginUser(username, password);
            
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            if (result.success) {
                alert('Login successful!');
                authModal.style.display = 'none';
                updateUIForLoggedInUser();
            } else {
                alert(`Login failed: ${result.error}`);
            }
        });
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('registerUsername').value;
            const password = document.getElementById('registerPassword').value;
            const email = document.getElementById('registerEmail').value;
            
            // Show loading state
            const submitBtn = registerForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Registering...';
            submitBtn.disabled = true;
            
            const result = await registerUser(username, password, email);
            
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            if (result.success) {
                alert('Registration successful! Please login.');
                loginTab.click(); // Switch to login tab
            } else {
                alert(`Registration failed: ${result.error}`);
            }
        });
    }
}

// Create auth modal if it doesn't exist
function createAuthModal() {
    const modalHTML = `
    <div id="authModal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            
            <div class="auth-tabs">
                <button id="loginTab" class="auth-tab active">Login</button>
                <button id="registerTab" class="auth-tab">Register</button>
            </div>
            
            <div id="loginForm" class="auth-form active">
                <h3>Login to Your Account</h3>
                <div class="form-group">
                    <label for="loginUsername">Username</label>
                    <input type="text" id="loginUsername" required>
                </div>
                <div class="form-group">
                    <label for="loginPassword">Password</label>
                    <input type="password" id="loginPassword" required>
                </div>
                <button type="submit" class="auth-submit">Login</button>
            </div>
            
            <div id="registerForm" class="auth-form">
                <h3>Create an Account</h3>
                <div class="form-group">
                    <label for="registerUsername">Username</label>
                    <input type="text" id="registerUsername" required>
                </div>
                <div class="form-group">
                    <label for="registerEmail">Email</label>
                    <input type="email" id="registerEmail" required>
                </div>
                <div class="form-group">
                    <label for="registerPassword">Password</label>
                    <input type="password" id="registerPassword" required>
                </div>
                <button type="submit" class="auth-submit">Register</button>
            </div>
        </div>
    </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add styles for the auth modal
    if (!document.getElementById('authModalStyles')) {
        const modalStyles = `
            .modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.7);
                z-index: 1000;
                justify-content: center;
                align-items: center;
            }
            
            .modal-content {
                background: var(--card-bg, #1a1a2e);
                border-radius: 15px;
                width: 90%;
                max-width: 500px;
                padding: 2rem;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
                position: relative;
                border: 1px solid var(--card-border, #2a2a4a);
            }
            
            .close-modal {
                position: absolute;
                top: 1rem;
                right: 1.5rem;
                font-size: 1.5rem;
                color: var(--text-dim, #ccc);
                cursor: pointer;
                transition: color 0.3s ease;
            }
            
            .close-modal:hover {
                color: var(--text-light, #fff);
            }
            
            .auth-tabs {
                display: flex;
                margin-bottom: 2rem;
                border-bottom: 1px solid var(--card-border, #2a2a4a);
            }
            
            .auth-tab {
                padding: 0.8rem 1.5rem;
                background: transparent;
                border: none;
                color: var(--text-dim, #ccc);
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
                position: relative;
                transition: color 0.3s ease;
            }
            
            .auth-tab:hover {
                color: var(--text-light, #fff);
            }
            
            .auth-tab.active {
                color: var(--accent-color, #f72585);
            }
            
            .auth-tab.active::after {
                content: '';
                position: absolute;
                bottom: -1px;
                left: 0;
                width: 100%;
                height: 2px;
                background: var(--accent-color, #f72585);
            }
            
            .auth-form {
                display: none;
            }
            
            .auth-form.active {
                display: block;
            }
            
            .auth-form h3 {
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                color: var(--text-light, #fff);
            }
            
            .form-group {
                margin-bottom: 1.5rem;
            }
            
            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
                color: var(--text-dim, #ccc);
                font-size: 0.9rem;
            }
            
            .form-group input {
                width: 100%;
                padding: 0.8rem 1rem;
                border-radius: 8px;
                border: 1px solid var(--card-border, #2a2a4a);
                background: var(--dark-surface, #121225);
                color: var(--text-light, #fff);
                font-size: 1rem;
                transition: border-color 0.3s ease;
            }
            
            .form-group input:focus {
                outline: none;
                border-color: var(--accent-color, #f72585);
            }
            
            .auth-submit {
                width: 100%;
                padding: 0.8rem;
                border: none;
                border-radius: 8px;
                background: var(--primary-color, #4361ee);
                color: white;
                font-size: 1rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .auth-submit:hover {
                background: var(--accent-color, #f72585);
                transform: translateY(-2px);
            }
            
            /* User Profile Button Styles */
            .user-profile-btn.logged-in {
                background: var(--accent-color, #f72585);
            }
            
            .user-profile-btn span {
                font-weight: 700;
                font-size: 1.2rem;
            }
            
            @media (max-width: 768px) {
                .modal-content {
                    width: 95%;
                    padding: 1.5rem;
                }
                
                .auth-tab {
                    padding: 0.6rem 1rem;
                }
            }
        `;
        
        const styleElement = document.createElement('style');
        styleElement.id = 'authModalStyles';
        styleElement.textContent = modalStyles;
        document.head.appendChild(styleElement);
    }
    
    // Initialize after creating
    setTimeout(initializeAuthModal, 100);
}

// Update UI for logged in user
function updateUIForLoggedInUser() {
    const userProfileBtn = document.getElementById('userProfileBtn');
    const userDropdownContent = document.getElementById('userDropdownContent');
    
    if (userProfileBtn && userDropdownContent && currentUser) {
        userProfileBtn.innerHTML = `<span>${currentUser.username.charAt(0).toUpperCase()}</span>`;
        userProfileBtn.classList.add('logged-in');
        
        userDropdownContent.innerHTML = `
            <a href="#profile"><i class="fas fa-user"></i> Profile</a>
            <a href="#favorites"><i class="fas fa-heart"></i> Favorites</a>
            <a href="#my-tickets"><i class="fas fa-ticket-alt"></i> My Tickets</a>
            <a href="#my-bookings"><i class="fas fa-basketball-ball"></i> My Court Bookings</a>
            <a href="#settings"><i class="fas fa-cog"></i> Settings</a>
            <a href="#" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        `;
        
        // Re-attach logout event listener
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                logoutUser();
            });
        }
        
        // If renderPlayerCards exists (from players.js), refresh player cards to show favorites
        if (typeof renderPlayerCards === 'function') {
            renderPlayerCards();
        }
    }
}

// Update UI for logged out user
function updateUIForLoggedOutUser() {
    const userProfileBtn = document.getElementById('userProfileBtn');
    const userDropdownContent = document.getElementById('userDropdownContent');
    
    if (userProfileBtn && userDropdownContent) {
        userProfileBtn.innerHTML = `<i class="fas fa-user"></i>`;
        userProfileBtn.classList.remove('logged-in');
        
        userDropdownContent.innerHTML = `
            <a href="#login"><i class="fas fa-sign-in-alt"></i> Login</a>
            <a href="#register"><i class="fas fa-user-plus"></i> Sign Up</a>
        `;
        
        // If renderPlayerCards exists (from players.js), refresh player cards to remove favorites
        if (typeof renderPlayerCards === 'function') {
            renderPlayerCards();
        }
    }
}
